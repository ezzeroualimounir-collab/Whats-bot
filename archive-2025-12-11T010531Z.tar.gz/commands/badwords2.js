const fs = require('fs');

const path = require('path');

const badWords = JSON.parse(

  fs.readFileSync(path.join(__dirname, '../data/badwords.json'), 'utf-8')

);

module.exports = async function handleBadwords(sock, chatId, message, userMessage, senderId) {

  const lowered = userMessage.toLowerCase();

  const found = badWords.some(word => lowered.includes(word));

  if (!found) return;

  await sock.sendMessage(chatId, {

    text: `🚫 الكلمة لي قلتها ممنوعة فالكروب، حاول تحترم راسك.`,

    mentions: [senderId]

  }, { quoted: message });

};