async function handleConfess(sock, chatId, message) {

  try {

    if (!chatId.endsWith('@g.us')) {

      return await sock.sendMessage(chatId, { text: '❌ هذا الأمر متاح فقط في المجموعات.' }, { quoted: message });

    }

    const sender = message.key.participant || message.key.remoteJid;

    const senderName = message.pushName || 'عضو';

    const groupMetadata = await sock.groupMetadata(chatId);

    const participants = groupMetadata.participants.map(p => p.id).filter(id => id !== sender);

    if (participants.length === 0) {

      return await sock.sendMessage(chatId,sender, { text: '😔 لا يوجد أعضاء آخرون للاعتراف لهم.' }, { quoted: message });

    }

    const randomIndex = Math.floor(Math.random() * participants.length);

    const target = participants[randomIndex];

    const text = `

╔══💘 *رسالة اعتراف* 💘══╗

@${sender.split('@')[0]} ❤️ يهمس لـ @${target.split('@')[0]}:

🌹 "قلبي اختارك من بين الجميع... هل تقبل مشاعري؟"

╚════════════════════╝

`;












    await sock.sendMessage(chatId, {

      text,

      mentions: [sender, target]

},{quoted: message });

  } catch (error) {

console.error('Error in handleConfess:', error);

  }

}

module.exports = { handleConfess };