async function resetlinkCommand(sock, chatId, message) {

    try {

        const groupMetadata = await sock.groupMetadata(chatId);

        const participants = groupMetadata.participants;

        const sender = message.author || message.key.participant || message.key.remoteJid;

        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';

        const isAdmin = participants?.some(p => p.id === sender && (p.admin === 'admin' || p.admin === 'superadmin'));

        const isBotAdmin = participants?.some(p => p.id === botId && (p.admin === 'admin' || p.admin === 'superadmin'));

        if (!isAdmin) {

            await sock.sendMessage(chatId, { text: '❌ هذا الأمر مخصص للمشرفين فقط.' });

            return;

        }

if (!isBotAdmin) {

            await sock.sendMessage(chatId, { text: '❌ يجب أن يكون البوت مشرفًا لإعادة تعيين رابط المجموعة.' });

            return;

        }

        const newCode = await sock.groupRevokeInvite(chatId);

        await sock.sendMessage(chatId, {

            text: `✅ تم إعادة تعيين رابط المجموعة:\n\n🔗 https://chat.whatsapp.com/${newCode}`

        });

    } catch (error) {

        console.error('❌ خطأ في resetlinkCommand:', error);

        await sock.sendMessage(chatId, { text: '❌ فشل في إعادة تعيين الرابط.' });

    }

}

module.exports = resetlinkCommand;