const fs = require('fs');

const path = require('path');

const groupsFilePath = path.join(__dirname, 'data', 'groups.json');

async function leaveGroupByNumber(sock, message, args) {

  const sender = message.key.remoteJid;

  // التأكد من تمرير رقم صحيح

  const groupNumber = parseInt(args[0]);

  if (isNaN(groupNumber)) {

    await sock.sendMessage(sender, { text: '❌ المرجو إدخال رقم صالح للمجموعة.' });

    return;

  }

  // قراءة ملف المجموعات

  let groups = [];

  try {

    const data = fs.readFileSync(groupsFilePath, 'utf-8');

    groups = JSON.parse(data);

  } catch (err) {

    console.error('❌ خطأ في قراءة ملف المجموعات:', err);

    await sock.sendMessage(sender, { text: '❌ فشل في قراءة قائمة المجموعات.' });

    return;

  }

  // التحقق من وجود الرقم في القائمة

  if (groupNumber < 1 || groupNumber > groups.length) {

    await sock.sendMessage(sender, { text: '❌ الرقم خارج نطاق قائمة المجموعات.' });

    return;

  }

  const group = groups[groupNumber - 1];

  try {

    await sock.groupLeave(group.id);

    await sock.sendMessage(sender, { text: '*✅ تم مغادرة المجموعة بنجاح.*' });

    // إزالة المجموعة من الملف بعد المغادرة

groups.splice(groupNumber - 1, 1);

    fs.writeFileSync(groupsFilePath, JSON.stringify(groups, null, 2));

  } catch (leaveErr) {

    console.error('❌ خطأ في مغادرة المجموعة:', leaveErr);

    await sock.sendMessage(sender, { text: '❌ فشل في مغادرة المجموعة.' });

  }

}

module.exports = leaveGroupByNumber;