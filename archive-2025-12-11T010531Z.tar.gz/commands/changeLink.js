const changeGroupLink = async (sock, msg) => {

  const jid = msg.key.remoteJid;

  // 1. التحقق إن كان في مجموعة

  if (!jid.endsWith('@g.us')) {

    await sock.sendMessage(jid, { text: '❌ هذا الأمر يُستخدم داخل المجموعات فقط.' }, { quoted: msg });

    return;

  }

  try {

    // 2. إعادة تعيين رابط الدعوة (groupRevokeInvite ترجع كود الدعوة الجديد)

    const newInviteCode = await sock.groupRevokeInvite(jid);

    // 3. 🟢 FIX: بناء رابط الدعوة بشكل صحيح باستخدام الكود المُعاد (newInviteCode)

    const newLink = `https://chat.whatsapp.com/${newInviteCode}`;

    // 4. 🟢 FIX: إرسال رسالة التأكيد بشكل صحيح مع تضمين الرابط

    await sock.sendMessage(jid, { 

      text: `✅ تم تغيير رابط المجموعة بنجاح!

*الرابط الجديد:* ${newLink}` 

    }, { quoted: msg });

  } catch (err) {

    // 5. رسالة الخطأ والتوضيح

    await sock.sendMessage(jid, { 

      text: '❌ فشل في تغيير الرابط. الأسباب المحتملة:\n1. البوت ليس مشرفًا في المجموعة.\n2. إعدادات المجموعة لا تسمح للمشرفين بتغيير الرابط.' 

    }, { quoted: msg });

    

    console.error('خطأ في تغيير الرابط:', err);

  }

};

module.exports = { changeGroupLink };

