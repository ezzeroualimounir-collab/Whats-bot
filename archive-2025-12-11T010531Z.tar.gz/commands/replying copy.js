const autoReplyMap = new Map();

autoReplyMap.set('سلام عليكم', 'وعليكم السلام ورحمة الله وبركاته 🌟');

autoReplyMap.set('مرحبا', 'مرحبا بك! كيف يمكنني مساعدتك؟ 😊');

autoReplyMap.set('بخير', 'الحمد لله على كل حال 🙏');

autoReplyMap.set('تصبحوا على خير', 'تصبح على خير، تصبحي على خير 😴');

autoReplyMap.set('صافا باي', 'باي باي، إلى اللقاء 👋');

autoReplyMap.set('كيف حالك', 'أنا جيد، شكرا لسؤالك! 👍');

autoReplyMap.set('ما الجديد', 'لا جديد، كل شيء على ما يرام 🤔');

autoReplyMap.set('شكرا', 'على الرحب والسعة! 🙏');

autoReplyMap.set('مع السلامة', 'مع السلامة، إلى اللقاء 👋');

autoReplyMap.set('الله يعطيك العافية', 'آمين، وإياك 🙏');

autoReplyMap.set('الله يخليك', 'آمين، وإياك 🙏');

autoReplyMap.set('صباح الخير', 'صباح النور ☀️');

autoReplyMap.set('مساء الخير', 'مساء النور 🌙');

autoReplyMap.set('كيف الأحوال', 'الحمد لله، بخير 🙏');

autoReplyMap.set('ما أخبارك', 'أنا جيد، شكرا لسؤالك! 👍');

autoReplyMap.set('أهلاً وسهلاً', 'أهلاً بك، تفضل 😊');

autoReplyMap.set('مرحباً', 'مرحباً بك، كيف يمكنني مساعدتك؟ 😊');

autoReplyMap.set('الله يسلمك', 'آمين، وإياك 🙏');

autoReplyMap.set('تصبح على خير', 'تصبح على خير، تصبحي على خير 😴');

autoReplyMap.set('باي باي', 'باي باي، إلى اللقاء 👋');

autoReplyMap.set('وااا', 'وااا، كيف يمكنني مساعدتك؟ 😊');

autoReplyMap.set('مرحباا', 'مرحباا، كيف حالك؟ 😊');

autoReplyMap.set('بخيير', 'الحمد لله، بخير 🙏');

autoReplyMap.set('كيفييي', 'أنا جيد، شكرا لسؤالك! 👍');

autoReplyMap.set('واااا', 'واااا، كيف يمكنني مساعدتك؟ 😊');
autoReplyMap.set('skot', 'skot nta bda, daba glsti tnhdr 💀');
autoReplyMap.set('choukran', 'wachkor mnin jak, chker mamatk 😏');

autoReplyMap.set('za3ma', 'za3ma 3lik nta? rah fih ntana 😂');

autoReplyMap.set('kif dayr', 'kif dayr nta? kayn fih bzzaf w nta tsawel 😑');

autoReplyMap.set('sbah lkhir', 'sbah zbel nta w lkhir 😴');

autoReplyMap.set('m3a slama', 'allah y3tik khir m3a slama, w matrja3ch 😂');

autoReplyMap.set('aji', 'aji daba wlli bla hdra nta 💀');

autoReplyMap.set('lah y3awnk', 'lah y3awn mamatk, nta t3awn m3a rassek 🤡');

autoReplyMap.set('finak', 'f lkhra nta b9iti 😂');

autoReplyMap.set('msa lkhir', 'msa zbel nta wlkhir 😴');
autoReplyMap.set('سكوت', 'سكوت نتي عاد بداتي الهضرة؟ غير بركي 😒');

autoReplyMap.set('زعما', 'زعما نتي زعما؟ وا راكي نكافة 😂');

autoReplyMap.set('كيف داير', 'كيف داير؟ داير بحال القرعة خاوي 🤣');

autoReplyMap.set('صباح الخير', 'صباح الخسارة، نعسي مزال 😴');

autoReplyMap.set('فينك', 'فينك نتي؟ كنتي فالحبس؟ 😂');

autoReplyMap.set('آجي', 'آجي نتي، راك ماشي مول الدار 😏');

autoReplyMap.set('مع السلامة', 'يالله، الله يعاون اللي شافك 👋');

autoReplyMap.set('شكرا', 'شكرا؟ سير تكمش 😌');

autoReplyMap.set('مساء الخير', 'مساء الغبرة 😆');

autoReplyMap.set('الله يعاونك', 'يعاونك فاش؟ ف النعاس؟ 😴');

autoReplyMap.set('كنبغيك', 'حتى أنا كنبغيك بزاف ❤️😍');

autoReplyMap.set('فينك', 'هاني هنا خيي، غير مشغول شوية 💬💖');

autoReplyMap.set('واش بخير', 'الحمد لله، نتمنى تكون حتى نتي بخير 🌸😊');

autoReplyMap.set('راك غبرتي', 'سمح ليا خيي، الظروف 🤍📵');

autoReplyMap.set('صباح النور', 'صباح الورد و الفل عليك 🌹🌞');

autoReplyMap.set('نووووم', 'نوم الهنا و الأحلام الزوينة 😴💤');

autoReplyMap.set('عافاك', 'مرحبا بيك، غير قول شنو باغي 🤝💗');

autoReplyMap.set('غادي نخرج', 'رد بالك وخلي بالك فراسك 🌆❤️');

autoReplyMap.set('الله يرضي عليك', 'آمين يا ربي، و يرضي عليك حتى نتي 🌟💖');

autoReplyMap.set('توحشت الضحك', 'آجي نضحكو شوية 😂💞');
autoReplyMap.set('صافي', 'صافي باركا هاني فهمت 🤐❤️');

autoReplyMap.set('جاوب', 'راني هنا، غير بشوية عليا 📲😅');

autoReplyMap.set('مالك', 'ما فيا والو، غير شويّة ديال الصمت 😶💭');

autoReplyMap.set('شنو بغيتي', 'بغيت غير نهضر معاك شوية 💌😊');

autoReplyMap.set('واخا', 'واخااا، ديما معاك 💪❤️');

autoReplyMap.set('هههه', 'هههه الله يعطينا وجهك 😂🔥');

autoReplyMap.set('ههه', 'ههه ضحكتيني وصافي 😆');

autoReplyMap.set('ههههههه', 'ضحكة من القلب 🤣❤️');

autoReplyMap.set('ياك', 'ياك بصح؟ ولا غير كتجرب فيا؟ 😏🤔');
async function handleAutoReply(sock, msg) {

  try {

    const jid = msg.key.remoteJid;

    const sender = msg.key.participant || msg.key.remoteJid;

    const text = msg.message.conversation || msg.message.extendedTextMessage?.text;

    if (text) {

      for (const [key, value] of autoReplyMap) {

        if (text.includes(key)) {

      await sock.sendMessage(jid, { text: value });
          break;

        }

      }

    }

  } catch (err) {

    console.error('❌ خطأ في handleAutoReply:', err);

  }

}

module.exports = { handleAutoReply };