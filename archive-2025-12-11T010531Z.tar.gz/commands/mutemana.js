const fs = require('fs');

const path = require('path');

const mutedFile = path.join(__dirname, '../data/muted.json');

function loadMutedData() {

  if (!fs.existsSync(mutedFile)) return {};

  return JSON.parse(fs.readFileSync(mutedFile));

}

async function handleMutedCheck(sock, message) {

  const chatId = message.key.remoteJid;

  const senderId = message.key.participant || message.key.remoteJid;

  const mutedData = loadMutedData();

  if (mutedData[chatId] && mutedData[chatId].includes(senderId)) {

    try {

      const deleteKey = {

        remoteJid: chatId,

        id: message.key.id,

        fromMe: false,

        participant: message.key.participant || message.key.remoteJid

      };

      console.log('🧹 محاولة حذف رسالة من:', senderId);

await sock.sendMessage(chatId, { delete: deleteKey });

    } catch (err) {

      console.error('❌ فشل حذف رسالة المكتوم:', err);

    }

  }

}

module.exports = { handleMutedCheck };