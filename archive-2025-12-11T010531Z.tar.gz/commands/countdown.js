const { proto } = require('@whiskeysockets/baileys');

module.exports = async function editMessage(sock, message) {

  const chatId = message.key.remoteJid;

  

  // 1. إرسال الرسالة الأولى وتخزين مفتاحها بالكامل

  const sentMsg = await sock.sendMessage(chatId, { text: 'mounir' });

  if (!sentMsg?.key) {

    console.error("فشل في إرسال الرسالة الأولية.");

    return;

  }

  // استخدام وقت انتظار آمن

  await new Promise(resolve => setTimeout(resolve, 5000)); 

  // 2. بناء محتوى الرسالة المعدلة كـ Protobuf (extendedTextMessage)

  const newContent = proto.Message.fromObject({

    extendedTextMessage: { 

      text: 'zerouali' 

    }

  });

  // 3. بناء رسالة التعديل (View Once Message) لتشغيل التعديل

  const editProto = proto.WebMessageInfo.fromObject({

      key: sentMsg.key, // مفتاح الرسالة التي سيتم تعديلها

      message: newContent, // المحتوى الجديد (zerouali)

      messageStubType: proto.WebMessageInfo.StubType.MESSAGE_EDIT, // نوع التعديل

      messageStubParameters: [newContent],

  });

  // 4. استخدام sock.relayMessage لإرسال التعديل

  await sock.relayMessage(chatId, editProto.toJSON(), {

    messageId: sentMsg.key.id,

    cachedGroupMetadata: {}

  });

  console.log(`تم إرسال أمر التعديل بنجاح لرسالة ID: ${sentMsg.key.id}`);

}

