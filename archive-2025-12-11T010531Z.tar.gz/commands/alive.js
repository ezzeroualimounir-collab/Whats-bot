const settings = require("../settings");
async function aliveCommand(sock, chatId, message) {
    try {
        const message1 = `*💡خدام أعشيري شنو بغيتي👑*


 





`;

        await sock.sendMessage(chatId, {
            text: message1,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
 
                    newsletterName: 'Elgrande mounir',
                    serverMessageId: -1
                }
            }
        }, { quoted: message });
    } catch (error) {
        console.error('Error in alive command:', error);
        await sock.sendMessage(chatId, { text: 'خدام اعشيري!' }, { quoted: message });
    }
}

module.exports = aliveCommand;