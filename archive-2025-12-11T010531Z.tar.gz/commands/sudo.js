const settings = require('../settings');
const { addSudo, removeSudo, getSudoList } = require('../lib/index');

function extractMentionedJid(message) {
    const mentioned = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (mentioned.length > 0) return mentioned[0];
    const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
    const match = text.match(/\b(\d{7,15})\b/);
    if (match) return match[1] + '@s.whatsapp.net';
    return null;
}

async function sudoCommand(sock, chatId, message) {
    const senderJid = message.key.participant || message.key.remoteJid;
    const ownerJid = settings.ownerNumber + '@s.whatsapp.net';
    const isOwner = message.key.fromMe || senderJid === ownerJid;
let target = null;
// منشن مباشر
if (  message.message?.extendedTextMessage?.contextInfo?.mentionedJid &&  message.message.extendedTextMessage.contextInfo.mentionedJid.length > 0
) {
  target = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
}
// رد على رسالة
else if (  message.message?.extendedTextMessage?.contextInfo?.participant
) {
  target = message.message.extendedTextMessage.contextInfo.participant;
}
    const rawText = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
    const args = rawText.trim().split(' ').slice(1);
    const sub = (args[0] || '').toLowerCase();

    if (!sub || !['اضف', 'حذف', 'ازالة', 'قائمة'].includes(sub)) {
        await sock.sendMessage(chatId, { text: '*اكتب : .نخبة وبعدها قائمة/ازالة/حذف/اضف تم منشن شخص او اكتب رقمه* ' },{quoted :message});
        return;
    }

    if (sub === 'قائمة') {
        const list = await getSudoList();
        if (list.length === 0) {
            await sock.sendMessage(chatId, { text: '*لا يوجد قائمة للنخبة⚠️.*' },{quoted :message});
            return;
        }
        const texter = list.map((j, i) => `${i + 1}. ${j}`).join('\n');
        await sock.sendMessage(chatId, { text: `*قائمة النخبة📃*:\n@${texter}`
     },{quoted :message});
        return;
    }

    if (!isOwner) {
        await sock.sendMessage(chatId, { text: '*❌ فقط المالك يمكنه تغيير اعدادات النخبة😉⚠️.*' },{quoted :message});
        return;
    }

    const targetJid = extractMentionedJid(message);
    if (!targetJid) {
        await sock.sendMessage(chatId, { text: '*من فضلك منشن شخص او اكتب رقمه لاضافته😊🪢.*' },{quoted :message});
        return;
    }

    if (sub === 'اضف') {
        const ok = await addSudo(targetJid);
        await sock.sendMessage(chatId, { text: ok ? `*✅ تمت اضافته للنخبة*: @${target.split('@')[0]}` : '*❌ فشل اضافة هذا العضو*',
       mentions: [target]                                },{quoted :message});
        return;
    }

    if (sub === 'حذف' || sub === 'ازالة') {
        const ownerJid = settings.ownerNumber + '@s.whatsapp.net';
        if (targetJid === ownerJid) {
            await sock.sendMessage(chatId, { text: '*لا يمكن ازالة المالك 🤨⁉️*.' },{quoted :message});
            return;
        }
        const ok = await removeSudo(targetJid);
        await sock.sendMessage(chatId, { text: ok ? `✅ تمت ازالته من النخبة: @${target.split('@')[0]}` : '*❌ فشل ازالته من النخبة*',
     mentions: [target]                                  },{quoted :message});
        return;
    }
}

module.exports = sudoCommand;


