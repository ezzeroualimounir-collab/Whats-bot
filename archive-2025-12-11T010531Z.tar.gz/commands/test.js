const path = require('path');

const fs = require('fs');

async function handleTestCommand(sock, msg) {

  const chatId = msg.key.remoteJid;

  try {

    const imagePath = path.join(__dirname, '../assets/bot_image.jpg');

    if (fs.existsSync(imagePath)) {

      const imageBuffer = fs.readFileSync(imagePath);

      await sock.sendMessage(chatId, {

        image: imageBuffer,

        caption: `

╔══════════༒༒══════════╗  

☠️ *آلـــآلـم 𝙱𝚢𝚗𝚝𝚊𝚏𝚒 𝚊𝚕𝚐𝚞𝚛𝚞𝚋 𝚖𝚢 𝚜𝚘𝚞𝚕*  

☁️ *كـــــظــلّ 𝙽𝚘𝚒𝚛 𝚎𝚝𝚎𝚛𝚗𝚎𝚕*  

☯️ *الصمتُ هو سِـــلـــــاحِي، 𝕷𝖆 𝖉𝖎𝖘𝖈𝖎𝖕𝖑𝖎𝖓𝖊*  

🕷️ *آلآلـــآم تَــحـــتـــضـــن السّمـــاء، 𝕷𝖊 𝖈𝖍𝖆𝖙𝖎𝖒𝖊𝖓𝖙*  

╚══════════༒༒══════════╝`,

      }, { quoted: msg });

      const audioPath = path.join(__dirname,'media','test.opus');

      if (fs.existsSync(audioPath)) {

        await sock.sendMessage(chatId, {

          audio: { url: audioPath },

          mimetype: 'audio/mp4',
ptt:true
        }, { quoted: msg });

      } else {

        console.log('ملف الصوت غير موجود');

      }

    } else {

      console.log('ملف الصورة غير موجود');

    }

  } catch (error) {

    console.error('خطأ في إرسال الرسائل:', error);

  }

}

module.exports = {handleTestCommand};