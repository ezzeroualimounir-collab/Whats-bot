const { loadJSON, saveJSON } = require('../lib/json'); // تأكد من وجود هذه الدوال
const dbFile = './data/married.json';

async function handleMarriage(sock, msg, args = []) {
  const sender = msg.sender || msg.key.participant || msg.key.remoteJid;
    const messageContent = msg.message || {};

const extendedText = messageContent.extendedTextMessage || {};

const contextInfo = extendedText.contextInfo || {};

const mentionedJid = contextInfo.mentionedJid || [];

const quotedParticipant =
contextInfo.participant || null;



  let target = null;

  if (mentionedJid.length > 0) {
    target = mentionedJid[0];
  } else if (quotedParticipant) {
    target = quotedParticipant;
  } else if (args.length > 0) {
    const number = args[0].replace(/\D/g, '');
    if (number) {
      target = number + '@s.whatsapp.net';
    }
  }

  if (!target) {
    return sock.sendMessage(chatId, {
      text: '👰‍♀️ يرجى الرد على شخص، منشنه أو كتابة رقمه بعد الأمر.',
    }, { quoted: msg });
  }

  if (target === sender) {
    return sock.sendMessage(chatId, {
text: '🤦‍♂️ لا يمكنك الزواج من نفسك.',
    }, { quoted: msg });
  }

  marriages[chatId] = marriages[chatId] || {};
  const groupMarriages = marriages[chatId];
  groupMarriages[sender] = groupMarriages[sender] || [];

  if (groupMarriages[sender].includes(target)) {
    return sock.sendMessage(chatId, {
      text: '💍 أنت بالفعل متزوج من هذا الشخص.',
    }, { quoted: msg });
  }

  groupMarriages[sender].push(target);
  saveJSON(dbFile, marriages);

  const marriageMessage = `
💞💍 ━━━💠 تهانينا 💠━━━ 💍💞

🤵 الزوج: @${sender.split('@')[0]}
👰 الزوجة: @${target.split('@')[0]}

💐 تم عقد القران بنجاح 💐
  `.trim();

  await sock.sendMessage(chatId, {
    text: marriageMessage,
    mentions: [sender, target],
  }, { quoted: msg });
}

module.exports = handleMarriage;


