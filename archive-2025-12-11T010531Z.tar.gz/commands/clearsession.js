const fs = require('fs');
const path = require('path');
const os = require('os');

const channelInfo = {
    contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterName: '彡『𝔈𝔩𝔤𝔯𝔞𝔫𝔡𝔢_.𝔪𝔬𝔲𝔫𝔦𝔯』彡',
            serverMessageId: -1
        }
    }
};

async function clearSessionCommand(sock, chatId, msg) {
    try {
        // Check if sender is owner
        if (!msg.key.fromMe) {
            await sock.sendMessage(chatId, { 
                text: '❌ هذا الأمر خاص بالمالك😉!',
             
            });
            return;
        }

        // Define session directory
        const sessionDir = path.join(__dirname, '../session');

        if (!fs.existsSync(sessionDir)) {
            await sock.sendMessage(chatId, { 
                text: '❌ لم أجد ملف الجلسة!',
         
            });
            return;
        }

        let filesCleared = 0;
        let errors = 0;
        let errorDetails = [];

        // Send initial status
        await sock.sendMessage(chatId, { 
            text: `🔍جارٍ حذف ملفات الجلسات لتسريع الأداء🥶...`
     
        });

        const files = fs.readdirSync(sessionDir);
        
        // Count files by type for optimization
        let appStateSyncCount = 0;
        let preKeyCount = 0;

        for (const file of files) {
            if (file.startsWith('app-state-sync-')) appStateSyncCount++;
            if (file.startsWith('pre-key-')) preKeyCount++;
        }

        // Delete files
        for (const file of files) {
            if (file === 'creds.json') {
                // Skip creds.json file
                continue;
            }
            try {
                const filePath = path.join(sessionDir, file);
                fs.unlinkSync(filePath);
                filesCleared++;
            } catch (error) {
                errors++;
                errorDetails.push(`فشل الحذف⁉️ ${file}: ${error.message}`);
            }
        }

        // Send completion message
        const message = `
            *彡『𝔈𝔩𝔤𝔯𝔞𝔫𝔡𝔢_.𝔪𝔬𝔲𝔫𝔦𝔯』彡*
*✅ تم إفراغ الحمولة الزائدة انظر للسرعة الآن😉⚡*!\n\n` +
                       `*📊 المعاينات*:\n` +
                       `*• مجموع الملفات المحذوفة*: ${filesCleared}\n` +
                       `• *حالة التطبيقات*: ${appStateSyncCount}\n` +
                       `•ملفات ال Pre-key: ${preKeyCount}\n` +
                       (errors > 0 ? `\n⚠️*أخطاء أثناء المعالجة : ${errors}\n${errorDetails.join('\n')}` : '');

        await sock.sendMessage(chatId, { 
            text: message
     
        });

    } catch (error) {
        console.error('Error in clearsession command:', error);
        await sock.sendMessage(chatId, { 
            text: '❌لم يتم تلبية طلب تنظيف الجلسة'
   
        });
    }
}

module.exports = clearSessionCommand; 