const fs = require('fs');

const path = require('path');

async function handleMyWives(sock, chatId, msg) {

  try {

    const senderId = (msg.key.participant || msg.key.remoteJid || '').split('@')[0]; // بدون @s.whatsapp.net

    const filePath = path.join(__dirname, '../data/married.json');

    if (!fs.existsSync(filePath)) {

      await sock.sendMessage(chatId, { text: '📂 لا يوجد سجل زواج بعد.' });

      return;

    }

    const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

    if (!data[chatId] || !data[chatId][senderId] || data[chatId][senderId].length === 0) {

      await sock.sendMessage(chatId, { text: '🙁 ليس لديك زوجات في هذه المجموعة.'
                                    },{quoted: msg });

return;

    }

    const myWives = data[chatId][senderId];

    const mentions = myWives.map(jid => `@${jid.split('@')[0]}`);

    const message = `
*💖 ═─═─═─═─═─═─═─═─═─═💖*
*✨ كَشْفُ سِجِلِّ القُلُوبِ المُنْضَمَّة ✨*
*💖 ═─═─═─═─═─═─═─═─═─═💖*
 ╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄╮          *الفحص تم على روح:*@${senderId} 
 ╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄╯
*✧ ═════ 💘 ═════ ✧*
╔═════.💍.═════════╗
*💞زِوْجِاتُك الحِالِيِين هُنِّ💞 :* 
${mentions.join('\n')}
╚═════.💍.═════════╝
*نَتَمَنَّى دَوَامَ الْحُبِّ وَ السَّعَادَة فِي كُلِّ قَلْبٍ 🌹*
`;

    await sock.sendMessage(chatId, {

      text: message,

      mentions: [myWives,senderId]

},{quoted: msg   });

  } catch (err) {

    console.error('🚫 خطأ في handleMyWives:', err);

    await sock.sendMessage(chatId, { text: '❌ حدث خطأ أثناء عرض الزوجات.' });

  }

}

module.exports = { handleMyWives };