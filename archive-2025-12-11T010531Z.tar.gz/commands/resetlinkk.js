async function resetlinkCommand(sock, chatId, senderIdRaw) {

    try {

        // تأكد من تنسيق معرف المرسل

        const senderId = senderIdRaw.includes('@s.whatsapp.net') ? senderIdRaw : senderIdRaw + '@s.whatsapp.net';

        // جلب بيانات المجموعة

        const groupMetadata = await sock.groupMetadata(chatId);

        // تحقق إذا كان المرسل مشرفًا

        const isAdmin = groupMetadata.participants.some(p => p.id === senderId && p.admin);

        if (!isAdmin) {

            await sock.sendMessage(chatId, { text: '❌ هذا الأمر مخصص للمشرفين فقط.' });

            return;

        }

        // تحقق إذا كان البوت مشرفًا

        const botId = sock.user.id.includes('@') ? sock.user.id : sock.user.id + '@s.whatsapp.net';

        const isBotAdmin = groupMetadata.participants.some(p => p.id === botId && p.admin);

        if (!isBotAdmin) {

            await sock.sendMessage(chatId, { text: '❌ يجب أن يكون البوت مشرفًا لإعادة تعيين رابط المجموعة.' });

            return;

        }

        // إعادة تعيين رابط الدعوة

const newCode = await sock.groupRevokeInvite(chatId);

        await sock.sendMessage(chatId, { 

            text: `✅ تم إعادة تعيين رابط المجموعة بنجاح:\n\n🔗 https://chat.whatsapp.com/${newCode}`

        });

    } catch (error) {

        console.error('حدث خطأ في أمر resetlink:', error);

        await sock.sendMessage(chatId, { text: '❌ حدث خطأ أثناء إعادة تعيين الرابط.' });

    }

}

module.exports = resetlinkCommand;