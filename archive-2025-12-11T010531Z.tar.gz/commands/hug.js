async function handleHug(sock, chatId, message) {

  const mentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

  const quotedParticipant = message.message?.extendedTextMessage?.contextInfo?.participant;

  

  let target = null;

  if (mentionedJid.length > 0) {

    target = mentionedJid[0];

  } else if (quotedParticipant) {

    target = quotedParticipant;

  } else {

    return sock.sendMessage(chatId, { text: '❌ الرجاء منشن شخص أو الرد على رسالته لأرسال الحضن.' }, { quoted: message });

  }

  const sender = message.key.participant || message.key.remoteJid;

  if (target === sender) {

    return sock.sendMessage(chatId, { text: '🤗 لا يمكنك احضان نفسك!' }, { quoted: message });

  }

  const text = `

╔═══════❤️🌸 *عـنـاق الـحـب* 🌸❤️═══════╗

💞 @${sender.split('@')[0]}

🤗 *فتح ذراعيه بكل دفء...*

*💖 ليـعـانـق 💖*

🌹@${target.split('@')[0]}

💘 *بحضن يُذيب البرود ويشعل القلوب!*  

🕊️ *الحضن أمان لا يُوصف بالكلمات...*

╚═══════🌷💑 *حضن أسطوري* 💑🌷═══════╝

`;

  await sock.sendMessage(chatId, {

    text,

    mentions: [sender, target]

  });

}

module.exports = { handleHug };