const fs = require('fs');

const path = require('path');

const dbFile = path.join(__dirname, '../data/married.json');

// تحميل بيانات الزواج

function loadMarriages() {

  try {

    if (!fs.existsSync(dbFile)) {

      fs.writeFileSync(dbFile, '{}');

    }

    return JSON.parse(fs.readFileSync(dbFile));

  } catch {

    return {};

  }

}

// حفظ بيانات الزواج

function saveMarriages(data) {

  fs.writeFileSync(dbFile, JSON.stringify(data, null, 2));

}

// أمر الطلاق

async function handleDivorce(sock, chatId, msg) {

  

  // 1. تحديد المعرّف الكامل واستخراج الرقم

  const senderJidFull = msg.key.participant || msg.key.remoteJid;

  const senderNumber = senderJidFull.split('@')[0]; 

  const marriages = loadMarriages();

  marriages[chatId] = marriages[chatId] || {};

  const group = marriages[chatId];

  // 2. تحديد مفتاح قاعدة البيانات (FIX: البحث بمرونة)

  let senderDbKey = senderJidFull; // نفترض أنه المعرّف الحالي أولاً

  // إذا لم نجد المعرّف الحالي، نبحث عن أي مفتاح يبدأ بالرقم لتغطية الصيغ غير القياسية

  if (!group[senderJidFull]) {

      // البحث عن المفتاح المخزن الذي يبدأ برقم المرسل (مثلاً @lid)

      const matchingKey = Object.keys(group).find(key => key.startsWith(senderNumber));

      if (matchingKey) {

          senderDbKey = matchingKey; 

      }

  }

  // الآن نستخدم المفتاح المُكتشف للبحث

  const myWives = group[senderDbKey] || []; 

  if (myWives.length === 0) {

    // إذا لم يتم العثور على أي زوجات، نرسل رسالة الخطأ

    return await sock.sendMessage(chatId, {

      text: '🙁 ليس لديك زوجات لتطلقهن.',

    }, { quoted: msg });

  }

  // 3. تحديد الطرف المستهدف (الزوجة)

  const context = msg.message?.extendedTextMessage?.contextInfo || {};

  const mentioned = context.mentionedJid || [];

  const quoted = context.participant;

  let target = null;

  if (mentioned.length > 0) {

    target = mentioned[0];

  } else if (quoted) {

    target = quoted;

  }

  if (!target) {

    return sock.sendMessage(chatId, {

      text: '🔍 من فضلك منشن الزوجة أو رد على رسالتها لتطليقها.',

    }, { quoted: msg });

  }

  // منع تطليق النفس

  if (target === senderJidFull || target === senderDbKey) {

     return sock.sendMessage(chatId, { text: '❌ لا يمكنك تطليق نفسك!' }, { quoted: msg });

  }

  if (!myWives.includes(target)) {

    return sock.sendMessage(chatId, {

      text: '❌ هذه ليست زوجتك!',

    }, { quoted: msg });

  }

  // 4. إزالة الزوجة وحفظ التغييرات (باستخدام المفتاح الصحيح senderDbKey)

  group[senderDbKey] = myWives.filter(jid => jid !== target);

  marriages[chatId] = group;

  saveMarriages(marriages);

  

  // 5. تجهيز الرسالة والمنشن

  const targetNumber = target.split('@')[0];

  const mentionsJids = [senderJidFull, target]; // JIDs الكاملة للمنشن

  await sock.sendMessage(chatId, {

    text: `
💔 ⚔️ ━━━ 💀 ━━━ ⚔️ 💔
       *إِنْـهَـاءُ عَـهْـدٍ قَـدِيـم*
💔 ⚔️ ━━━ 💀 ━━━ ⚔️ 💔
*بِـقَـرَارٍ فَـصْـلٍ صَـارِمٍ، وَإِرادَةٍ عَـادَلَـةٍ فَـضَّتْ الـرِّبَاط:*
╭━💔━━━⚔️━━━━━⚔️━━━💔━╮
┊⚔️*الـطـرف الأول (المُنهي):* @${senderNumber}
┊💔*الـطـرف الـثـانـي (المُنْهَى):*@${targetNumber}
╰━💔━━━⚔️━━━━━⚔️━━━💔━╯
*نُـسجِّلُ في مَـحْفَلِ الـفَـصْـلِ، قَـرَارَ الـنِّـهَـايَة:*
*｡･ﾟ💔ﾟ･｡⚔️･ﾟ💔ﾟ･｡*
  *⛓️ تـسـجـيـل قـطـع الـعـهـد ⛓️*
*｡･ﾟ💔ﾟ･｡⚔️･ﾟ💔ﾟ･｡*

*تَمَّ إِنْهَاءُ العَقْدِ الافتراضي بِشَكْلٍ نِهَائِيٍّ وَبَاتَ كُلُّ طَرَفٍ حُراً.*
*نَتَمَنَّى لِكِلَا الطَّرَفَيْنِ سَلَامَةَ المَسِيرِ الـمُنْفَصِل.*
💀💔 *༺═─══─═─═─═─═─═─═─═༻* 💔💀
`,

    contextInfo: { mentionedJid: mentionsJids } 

  }, { quoted: msg });

}

module.exports = { handleDivorce };

