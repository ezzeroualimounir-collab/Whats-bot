module.exports = async function getProfile(sock, message) {

  const groupId = message.key.remoteJid;

  const mentioned = message.message?.extendedTextMessage?.contextInfo?.mentionedJid;

  if (!groupId.endsWith('@g.us') || !mentioned || mentioned.length === 0) {

    await sock.sendMessage(groupId, { text: '❌ منشن الشخص المطلوب بهذا الشكل:\n\n@الرقم .بروفايل' }, { quoted: message });

    return;

  }

  const targetJid = mentioned[0]; // معرف العضو

  try {

    const ppUrl = await sock.profilePictureUrl(targetJid, 'image').catch(() => null);

    const contact = await sock.onWhatsApp(targetJid);
      
    const number = targetJid.split('@')[0]; // استخراج الرقم بدون @s.whatsapp.net

    const name = contact[0]?.notify || contact[0]?.vname || number;

    const caption = `╭━━━〔 👤 مـعـلـومـات الـعـضـو 〕━━━╮

🪪 الاسم: *${name}*

📞 الرقم: *${number}*

🙋‍♂️ منشن: @${number}

╰━━━━━━━━━━━━━━━━━━╯`;

    await sock.sendMessage(groupId, {

      ...(ppUrl

        ? { image: { url: ppUrl }, caption, mentions: [targetJid] }

        : { text: caption, mentions: [targetJid] })

    }, { quoted: message });

} catch (err) {

    console.error('❌ خطأ:', err);

    await sock.sendMessage(groupId, { text: '❌ لم أتمكن من جلب بروفايله.' }, { quoted: message });

  }

};