module.exports = async function emptyGroup(sock, message) {

  const ownerNumber = '212723302406'; // رقمك بصيغة واتساب

  const botNumber = sock.user.id;

  const from = message.key.remoteJid;

  const senderNumber = (message.key.participant || message.key.remoteJid).split('@')[0];

if (senderNumber !== botNumber) {
  await sock.sendMessage(from, { text: '🚫 هذا الأمر خاص بالمالك فقط.' });
  return;
}

  const metadata = await sock.groupMetadata(from);

  const participants = metadata.participants;

  const toKick = participants

    .filter(p => p.id !== ownerNumber && p.id !== botNumber)

    .map(p => p.id);

  if (toKick.length === 0) {

    await sock.sendMessage(from, { text: '✅ لا يوجد أعضاء لطردهم.' });

    return;

  }

  for (const user of toKick) {

    try {

      await sock.groupRemove(from, [user]);

    } catch (e) {

      console.log(`فشل في طرد ${user}:`, e);

    }

  }

  await sock.sendMessage(from, { text: '✅ تم إفراغ المجموعة بنجاح (عدا المالك والبوت).' });

};