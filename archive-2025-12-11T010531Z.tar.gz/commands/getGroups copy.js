let cachedGroups = []; // لتخزين JIDs الخاصة بالمجموعات مؤقتًا

const getGroups = async (sock, message) => {

  try {

    const groups = await sock.groupFetchAllParticipating();

    const groupList = Object.values(groups);

    cachedGroups = groupList.map(g => g.id); // حفظ JIDs

    if (!message.key.remoteJid) {

      console.error('❌ خطأ: message.key.remoteJid غير موجود');

      return;

    }

    if (groupList.length === 0) {

      await sock.sendMessage(message.key.remoteJid, { text: '❗البوت ليس موجودًا في أي مجموعة حالياً.' });

      return;

    }

    let text = '*📋 قائمة المجموعات التي يشارك فيها البوت:*\n\n';

    groupList.forEach((group, index) => {

      text += `*${index+1}.* ${group.subject}\n`;

    });

    text += '\n✏️ للانسحاب من مجموعة، أرسل: .غادر <رقم المجموعة>';

    await sock.sendMessage(message.key.remoteJid, { text });

  } catch (error) {

    console.error('❌ خطأ في جلب المجموعات:', error);

    if (message.key.remoteJid) {

      await sock.sendMessage(message.key.remoteJid, { text: '⚠️ حدث خطأ أثناء جلب المجموعات.' });

    }

  }

};

const getCachedGroups = () => cachedGroups; // التصدير

module.exports = { getGroups, getCachedGroups };