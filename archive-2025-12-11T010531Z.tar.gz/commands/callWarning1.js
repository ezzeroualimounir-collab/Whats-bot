const fs = require('fs');

const path = require('path');

// ملف لتخزين التحذيرات

const warningsFile = path.join(__dirname, '..', 'data', 'callWarnings.json');

// تحميل التحذيرات من الملف

function loadWarnings() {

  if (!fs.existsSync(warningsFile)) return {};

  return JSON.parse(fs.readFileSync(warningsFile));

}

// حفظ التحذيرات

function saveWarnings(data) {

  fs.writeFileSync(warningsFile, JSON.stringify(data, null, 2));

}

// الدالة الرئيسية

async function handleCall(sock, callEvent) {

  try {

    const callerId = callEvent.from;

    // تجاهل المكالمات من غير الجروبات

    if (!callerId.endsWith('@g.us')) return;

    const metadata = await sock.groupMetadata(callerId);

    const admins = metadata.participants.filter(p => p.admin).map(p => p.id);

    const userId = callEvent.participant;

    // لا تطبق على المشرفين

    if (admins.includes(userId)) {

      await sock.sendMessage(callerId, {

        text: `⚠️ المستخدم @${userId.split('@')[0]} قام بمكالمة، لكن تم تجاهلها لأنه مشرف.`

      });

      return;

    }

    // تحميل التحذيرات

    const data = loadWarnings();

if (!data[callerId]) data[callerId] = 0;

    if (!data[callerId][userId]) data[callerId][userId] = 0;

    data[callerId][userId] += 1;

    saveWarnings(data);

    // إنذار أو طرد

    if (data[callerId][userId] >= 3) 

      await sock.groupParticipantsUpdate(callerId, [userId], 'remove');

      await sock.sendMessage(callerId, 
{
        text:` ❌${userId.split('@')[0]} تم طرده من المجموعة بعد 3 مكالمات!`

      });

      delete data[callerId][userId];

      saveWarnings(data);

 
}else{
      await sock.sendMessage(callerId, 
  {

        text: `⚠️ ممنوع المكالمات! (data${[callerId][userId]/3} على@${userId.split('@')[0]}`

      });

    }

  } catch (err) {

    console.error('❌ خطأ في معالجة المكالمة:', err);

  }

}

// التصدير

module.exports = {

  handleCall

};