const fs = require('fs');

const path = require('path');

const warningsFile = path.join(__dirname, '../data/callWarnings.json');

function loadWarnings() {

  try {

    const data = fs.readFileSync(warningsFile);

    return JSON.parse(data);

  } catch {

    return {};

  }

}

function saveWarnings(data) {

  fs.writeFileSync(warningsFile, JSON.stringify(data, null, 2));

}

async function handleCall(sock, callEvent) {

  const { from, id } = callEvent;

const isGroup = id.endsWith('@g.us');

if (!isGroup) return;

 

  const userJid = from;

  const warnings = loadWarnings();

  warnings[userJid] = (warnings[userJid] || 0) + 1;

  if (warnings[userJid] >= 3) {

    await sock.sendMessage(userJid, { text: '🚫 تم طردك بسبب كثرة المكالمات! (3/3)' });

    await sock.groupParticipantsUpdate(id, [userJid], 'remove').catch(() => {});

    delete warnings[userJid];

  } else {

    await sock.sendMessage(userJid, { text: `*⚠️ إنذار ${warnings[userJid]}: يرجى عدم الاتصال بالمجموعة.*` });

  }

  saveWarnings(warnings);

}

module.exports = { handleCall };