const { downloadContentFromMessage, getContentType } = require('@whiskeysockets/baileys');

module.exports = async function revealViewOnceAudio(sock, message) {

    const chatID = message.key.remoteJid;

    const command = '.افتح'; 

    

    const quotedContext = message.message?.extendedTextMessage?.contextInfo;

    

    if (!quotedContext || !quotedContext.quotedMessage) {

        await sock.sendMessage(chatID, { text: `⚠️ يُرجى استخدام ${command} بالرد (اقتباس) على رسالة وسائط.` }, { quoted: message });

        return; 

    }

    const quotedMsg = quotedContext.quotedMessage;

    

    // 1. تحديد كائن الوسائط الداخلي

    const quotedAudio = quotedMsg.audioMessage;

    const quotedImage = quotedMsg.imageMessage;

    const quotedVideo = quotedMsg.videoMessage;

    

    // تحديد نوع الوسائط والمحتوى المراد تحميله

    let streamType;

    let sendOptions = {};

    let mediaContent;

    if (quotedAudio) {

        streamType = 'audio';

        sendOptions = { audio: null, mimetype: 'audio/mp4', ptt: true };

        mediaContent = quotedAudio;

    } else if (quotedImage) {

        streamType = 'image';

        sendOptions = { image: null, caption: quotedImage.caption || '' };

        mediaContent = quotedImage;

    } else if (quotedVideo) {

        streamType = 'video';

        sendOptions = { video: null, caption: quotedVideo.caption || '' };

        mediaContent = quotedVideo;

    } else {

        // إذا لم يكن أي من الأنواع المدعومة

        await sock.sendMessage(chatID, { text: '❌ الاقتباس يجب أن يشير إلى وسائط (صوت، صورة، أو فيديو).' }, { quoted: message });

        return;

    }

    // 2. التحقق من خاصية View Once مباشرةً على كائن الوسيط

    // هذا هو نفس المنطق الذي يعمل لديك لفك تشفير الصور

    const isViewOnce = mediaContent.viewOnce; 

    

    if (!isViewOnce) {

        await sock.sendMessage(chatID, { text: '❌ الوسائط المقتبسة ليست رسالة تُعرض لمرة واحدة.' }, { quoted: message });

        return;

    }

    // 3. تحميل وإرسال الوسائط (باستخدام طريقة Stream الموثوقة)

    try {

        const stream = await downloadContentFromMessage(mediaContent, streamType);

        let buffer = Buffer.from([]);

        for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

        

        // إرسال الوسائط بشكل عادي (غير view once)

        sendOptions[streamType] = buffer;

        await sock.sendMessage(chatID, sendOptions, { quoted: message });

        

        console.log(`[BOT] تم فك تشفير وإعادة إرسال وسيط من نوع ${streamType} بنجاح.`);

    } catch (error) {

        console.error(`فشل في تحميل أو إرسال الوسائط من نوع ${streamType}:`, error);

        await sock.sendMessage(chatID, { text: `عذراً، حدث خطأ أثناء فك تشفير ${streamType}.` }, { quoted: message });

    }

};

