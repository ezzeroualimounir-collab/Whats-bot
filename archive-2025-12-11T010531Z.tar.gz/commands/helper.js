const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
    const helpMessage = `
╔═══════════════════╗
   *🤖 ${settings.botName || '∆§Elgrande mounir§∆'}*  
   Version: *${settings.version || '3.0.0'}*
   by ${settings.botOwner || 'elgrande mounir'}

╚═══════════════════╝

╚═══════════════════╝

*الأوامر المتاحة:*

╔═══════════════════╗
🌐 *الأوامر العامة*:
║ ➤ .مساعدة or .قائمة
║ ➤ .تست
║ ➤ .نطق <text>
║ ➤ .مطور
║ ➤ .كلمات <song_title
║ ➤ .عرض
║ ➤ .تزوج
║ ➤ .زوجتي
║ ➤ .trt <text> <lang>
╚═══════════════════╝ 

╔═══════════════════╗
👮‍♂️ *أوامر الأدمين*:
║ ➤ .حظر @user
║ ➤ .ترقية @user
║ ➤ .خفض @user
║ ➤ .كتم <minutes>
║ ➤ .الغاء_كتم
║ ➤ .حذف or .ح
║ ➤ .طرد @user
║ ➤ .تحذيرات @user
║ ➤ .تحذير @user
║ ➤ .منع_رابط
║ ➤ .منع_كلمات
║ ➤ .تنظيف
║ ➤ .منشن <message>
║ ➤ .طاغي
║ ➤ .بلوك
║ ➤ .فخ
║ ➤ .الغاء_بلوك
║ ➤ .اعضاء
║ ➤ .مخفي <message>
║ ➤ .تغيير_رابط
║ ➤ .منع_منشن <on/off>
║ ➤ .ترحيب <on/off>
║ ➤ .توديع <on/off>
║ ➤ .ضع_وصف <description>
║ ➤ .ضع_اسم <new name>
║ ➤ .ضع_صورة (reply to image)
╚═══════════════════╝

╔═══════════════════╗
🎨 *أوامر الصور والستيكرز*:
║ ➤ .تغشيم <image>
║ ➤ .لصورة <reply to sticker>
║ ➤ .ستيكر <reply to image>
║ ➤ .حذف_خلفية
║ ➤ .remini
║ ➤ .قص <reply to image> 
║ ➤ .مزج <emj1>+<emj2>
╚═══════════════════╝  

╔═══════════════════╗
🤖 *الذكاء الاصطناعي*:
║ ➤ .gpt <question>
║ ➤ .gemini <question>
║ ➤ .تخيل <prompt>
║ ➤ .ابتكر <prompt>
║ ➤ .sora <prompt>
╚═══════════════════╝

╔═══════════════════╗
📥 *أوامر التنزيل*:
║ ➤ .تشغيل <song_name>
║ ➤ .اغنية <song_name>
║ ➤ .انستغرام <link>
║ ➤ .فيسبوك <link>
║ ➤ .تيك_طوك <link>
║ ➤ .فيديو <song name>
║ ➤ .يوتيوب <Link>
╚═══════════════════╝
هادشي لي عطا الله 🙌😂`;

try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        
        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {

newsletterName: '∆§Elgrande mounir§∆',
                        serverMessageId: -1
                    }
                }
            },{ quoted: message });
        } else {
            console.error('Bot image not found at:', imagePath);
            await sock.sendMessage(chatId, { 
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {

                        newsletterName: '∆§Elgrande mounir§∆',
                        serverMessageId: -1
                    } 
                }
            });
        }
    } catch (error) {
        console.error('Error in help command:', error);
        await sock.sendMessage(chatId, { text: helpMessage });
    }
}

module.exports = helpCommand;
