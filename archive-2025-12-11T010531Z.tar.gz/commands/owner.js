const path = require('path');

const fs = require('fs');

async function ownerCommand(sock, msg) {

  const chatId = msg.key.remoteJid;

  try {

    const imagePath = path.join(__dirname, '../assets/bot_image.jpg');

    if (fs.existsSync(imagePath)) {

      const imageBuffer = fs.readFileSync(imagePath);

      await sock.sendMessage(chatId, {

        image: imageBuffer,

        caption: `
╭─━━━━𖤐🩸𖤐━━━━─╮  

🩸 _*NARUTO* ☁️_  

_*『彡『𝔈𝔩𝔤𝔯𝔞𝔫𝔡𝔢_.𝔪𝔬𝔲𝔫𝔦𝔯』彡』*_  

╰─━━━━𖤐🩸𖤐━━━━─╯  

🌑 ~*الظل خلف الشاشات...*~  

🩸 ~*مبرمج من عالم الأكاتسوكي*~  

⚡ _*19 سنة - مغربي 🇲🇦*_  

☁️ ~*"الكود هو السلاح... والهدوء هو القوة"*~  

📡 *تواصل معي ان كنت تجرؤ:*  

🔗 https://wa.me/212626172505
`,

      }, { quoted: msg });

      const audioPath = path.join(__dirname,'media','owner.opus');

      if (fs.existsSync(audioPath)) {

        await sock.sendMessage(chatId, {

          audio: { url: audioPath },

          mimetype: 'audio/mp4',
ptt:true 
        }, { quoted: msg });

      } else {

        console.log('ملف الصوت غير موجود');

      }

    } else {

      console.log('ملف الصورة غير موجود');

    }

  } catch (error) {

    console.error('خطأ في إرسال الرسائل:', error);

  }

}

module.exports = ownerCommand;