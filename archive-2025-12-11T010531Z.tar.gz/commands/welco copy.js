// commands/welcome.js

const welcome = async (sock, message) => {

  try {

    const { key: { remoteJid: groupId } } = message;

    const mentioned = message.message?.extendedTextMessage?.contextInfo?.mentionedJid;

    if (!groupId.endsWith('@g.us') || !mentioned?.length) {

      await sock.sendMessage(groupId, {

        text: '❌ منشن الشخص المطلوب بهذا الشكل:\n\n@الرقم .ترحيب'

      }, { quoted: message });

      return;

    }

    const [targetJid] = mentioned;

    const ppUrl = await sock.profilePictureUrl(targetJid, 'image').catch(() => null);

    const name = `@${targetJid.split('@')[0]}`;

    const caption = `

⚡━━━━━⚡🩸⚡━━━━━⚡
💠 *~مرحباً بك~* @${name} 
💠 *~في المجموعة~* ${groupId.split('@')[0]}
💠 *~نتمنى لك وقتاً ممتعاً~*
💠 *~معنا~*
💠 *~نحن سعداء بإنضمامك إلينا~*
💠 *~نأمل أن تجد ما تبحث عنه~*
💠 *~في مجموعتنا~*
⚡━━━━━⚡🩸⚡━━━━━⚡

`;

    if (ppUrl) {

      await sock.sendMessage(groupId, { image: { url: ppUrl }, caption, mentions: [targetJid] });

    } else {

      await sock.sendMessage(groupId, { text: caption, mentions: [targetJid] });

    }

  } catch (err) {

    console.error('❌ خطأ:', err);

  }

};

module.exports = welcome;