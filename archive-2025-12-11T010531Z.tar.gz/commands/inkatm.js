const fs = require('fs');

const path = require('path');

const mutedPath = path.join(__dirname, '../data/muted.json');

async function handleUnmuteCommand(sock, msg) {

  const chatId = msg.key.remoteJid;
const groupMetadata = await sock.groupMetadata(chatId);

const senderId = msg.key.participant || msg.key.remoteJid;

const isAdmin = groupMetadata.participants.some(p =>

  p.id === senderId && (p.admin === 'admin' || p.admin === 'superadmin')

);

if (!isAdmin) {

  await sock.sendMessage(chatId, {

    text: '❌ هذا الأمر خاص بالمشرفين فقط.',

  }, { quoted: msg });

  return;

}
  if (fs.existsSync(mutedPath)) {

    fs.unlinkSync(mutedPath);

    const unmuteMessage = `

╔══════════════╗

👑 تم إلغاء الكتم عن الجميع بنجاح! 👑

🔓 الآن يمكن للجميع التحدث بحرية!

╚══════════════╝

    `.trim();

    await sock.sendMessage(chatId, { text: unmuteMessage });

  } else {

    await sock.sendMessage(chatId, { text: '⚠️ لا يوجد أحد مكتوم حالياً.' });

  }

}

module.exports = { handleUnmuteCommand };