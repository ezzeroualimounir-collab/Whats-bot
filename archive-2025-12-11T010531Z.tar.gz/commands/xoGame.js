// xoGame.js

const gameState = new Map();

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

const initialBoard = () => [

  ['1️⃣', '2️⃣', '3️⃣'],

  ['4️⃣', '5️⃣', '6️⃣'],

  ['7️⃣', '8️⃣', '9️⃣']

];

function renderBoard(board) {

  return board.map(row => row.join('')).join('\n');

}

function checkWin(board, symbol) {

  const winLines = [

    // Rows

    [[0,0],[0,1],[0,2]],

    [[1,0],[1,1],[1,2]],

    [[2,0],[2,1],[2,2]],

    // Columns

    [[0,0],[1,0],[2,0]],

    [[0,1],[1,1],[2,1]],

    [[0,2],[1,2],[2,2]],

    // Diagonals

    [[0,0],[1,1],[2,2]],

    [[0,2],[1,1],[2,0]],

  ];

  return winLines.some(line => line.every(([r, c]) => board[r][c] === symbol));

}

async function xoGame(sock, message, args) {

  const chatId = message.key.remoteJid;

  if (!chatId) return;

  // بدء لعبة جديدة إذا لم تكن موجودة

  if (!gameState.has(chatId)) {

    const board = initialBoard();

    gameState.set(chatId, { board, currentPlayer: '⭕', gameOver: false });

    // عد تنازلي
  const sentMsg = await sock.sendMessage(chatId, { text: "⏳ تبدأ اللعبة خلال: 10..." }, { quoted: message });

  for (let i = 9; i >= 0; i--) {

    await new Promise(res => setTimeout(res, 1000));

    await sock.sendMessage(chatId, { text: `⏳ تبدأ اللعبة خلال: ${i}...` }, {

      messageId: sentMsg.key.id,

      edit: true

    });

  }


    await sock.sendMessage(chatId, { text: `🎮 لعبة XO بدأت!\n${renderBoard(initialBoard())}\n\n👤 الدور على: ⭕` }, { quoted: message });

    return;

  }

  const game = gameState.get(chatId);

  if (game.gameOver) {

    await sock.sendMessage(chatId, { text: "🔁 اللعبة منتهية. أرسل .xo لبدء جديدة." }, { quoted: message });
    gameState.delete(chatId);

    return;

  }

  const num = parseInt(args[0]);

  if (isNaN(num) || num < 1 || num > 9) {

    await sock.sendMessage(chatId, { text: "❌ أرسل رقم من 1 إلى 9 لاختيار الخانة." }, { quoted: message });

    return;

  }

  const row = Math.floor((num - 1) / 3);

  const col = (num - 1) % 3;

  const cell = game.board[row][col];

  if (cell === '⭕' || cell === '✖') {

    await sock.sendMessage(chatId, { text: "❌ هذه الخانة محجوزة." },
 { quoted: message });
    return;

  }

  game.board[row][col] = game.currentPlayer;

  // فحص الفوز

  if (checkWin(game.board, game.currentPlayer)) {

    await sock.sendMessage(chatId, { text: `🏆 اللاعب ${game.currentPlayer} فاز!\n${renderBoard(game.board)}` }, { quoted: message });

    gameState.delete(chatId);

    return;

  }

  // فحص التعادل

  const full = game.board.flat().every(c => c === '⭕' || c === '✖');

  if (full) {

    await sock.sendMessage(chatId, { text: `🤝 تعادل!\n\n${renderBoard(game.board)}` }, { quoted: message });
    gameState.delete(chatId);

    return;

  }

  // تبديل الدور

  game.currentPlayer = game.currentPlayer === '⭕' ? '✖' : '⭕';

  await sock.sendMessage(chatId, { text: `🎮 الدور الآن على: ${game.currentPlayer}\n\n${renderBoard(game.board)}` }, { quoted: message });

};
module.exports = { xoGame };