const fs = require('fs');

const path = require('path');

const mutedFile = path.join(__dirname, '../data/muted.json');

// تحميل البيانات

function loadMutedData() {

  if (!fs.existsSync(mutedFile)) return {};

  return JSON.parse(fs.readFileSync(mutedFile));

}

// الدالة الأساسية للتحقق وحذف الرسائل

async function handleMutedCheck(sock, message) {

  const chatId = message.key.remoteJid;

  const senderId = message.key.participant || message.key.remoteJid;

  const mutedData = loadMutedData();

  if (mutedData[chatId] && mutedData[chatId].includes(senderId)) {

    try {

      await sock.sendMessage(chatId, {

        delete: {

          remoteJid: chatId,

          fromMe: false,

          id: message.key.id,

          participant: message.key.participant || message.key.remoteJid

        }

      });

    } catch (err) {

      console.error('❌ فشل في حذف رسالة المكتوم:', err);

    }

  }

}

module.exports = { handleMutedCheck };