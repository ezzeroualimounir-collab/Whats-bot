const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
    const helpMessage = `
╔═─═─═─═─═─═─═─═─═─═─═╗  
🌑 🩸 𝔸𝕂𝔸𝕋𝕊𝕌𝕂𝐼 𝕊ℍ𝔸𝔻𝕆𝕎 🩸 🌑  
╚═─═─═─═─═─═─═─═─═─═─═╝  

╔═══─═─═─═─═─═─═─═─═══╗  
⫷ 𝐀𝐃𝐌𝐈𝐍 - الأوامر الإدارية ⫸  
🩸 *.طرد @user* – طرد الهدف  
🩸 *.حظر / .بلوك* – حظر العضو  
🩸 *.كتم / .إلغاء_كتم*  
🩸 *.ترقية / .خفض*  
🩸 *.منع_رابط | .منع_منشن*  
🩸 *.ترحيب / .توديع [on/off]*  
🩸 *.تنظيف / .تحديد / .منشن <نص>*  
╚═══─═─═─═─═─═─═─═─═══╝  

╔═══─═─═─═─═─═─═─═─═══╗  
⫷ 💬 𝐂𝐇𝐀𝐓 - أوامر المحادثة ⫸  
🩸 *.مساعدة / .قائمة*  
🩸 *.تست* – اختبار البوت  
🩸 *.نطق <نص>* – تحويل نص لصوت  
🩸 *.اعترف / .تحدي / .مين_الوسيم*  
🩸 *.فكاهة / .عرض*  
╚═══─═─═─═─═─═─═─═─═══╝  

╔═══─═─═─═─═─═─═─═─═══╗  
⫷ 💞 العلاقات والزواج ⫸  
🩸 *.تزوج @* – زواج الظل  
🩸 *.زوجتي*  
🩸 *.طلاق*  
🩸 *.احضن @*  
╚═══─═─═─═─═─═─═─═─═══╝  

╔═══─═─═─═─═─═─═─═─═══╗  
⫷ 🤖 الذكاء الاصطناعي ⫸  
🩸 *.gpt / .gemini*  
🩸 *.تخيل / .ابتكر / .sora*  
╚═══─═─═─═─═─═─═─═─═══╝  

╔═══─═─═─═─═─═─═─═─═══╗  
⫷ 🎨 الصور والستيكرات ⫸  
🩸 *.ستيكر / .لصورة*  
🩸 *.حذف_خلفية / .تغشيم / .مزج / .remini*  
╚═══─═─═─═─═─═─═─═─═══╝  

╔═══─═─═─═─═─═─═─═─═══╗  
⫷ 📥 التحميلات ⫸  
🩸 *.تشغيل / .أغنية / .فيديو*  
🩸 *.يوتيوب / .انستا / .تيك_توك / .فيسبوك*  
╚═══─═─═─═─═─═─═─═─═══╝  

╔═══─═─═─═─═─═─═─═─═══╗  
⫷ 🩸 الظل والهوية ⫸  
🩸 *.مطور*  
🩸 *.من_أنا؟*  
╚═══─═─═─═─═─═─═─═─═══╝`;

try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        
        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {

newsletterName: '∆§Elgrande mounir§∆',
                        serverMessageId: -1
                    }
                }
            },{ quoted: message });
        } else {
            console.error('Bot image not found at:', imagePath);
            await sock.sendMessage(chatId, { 
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {

                        newsletterName: '∆§Elgrande mounir§∆',
                        serverMessageId: -1
                    } 
                }
            });
        }
    } catch (error) {
        console.error('Error in help command:', error);
        await sock.sendMessage(chatId, { text: helpMessage });
    }

const audioPath = path.join(__dirname,'media','pain.opus');

      if (fs.existsSync(audioPath)) {

        await sock.sendMessage(chatId, {

          audio: { url: audioPath },

          mimetype: 'audio/mp4',
ptt:true
        }, { quoted: message });

      } else {

        console.log('ملف الصوت غير موجود');

      }
}
     
module.exports = helpCommand;