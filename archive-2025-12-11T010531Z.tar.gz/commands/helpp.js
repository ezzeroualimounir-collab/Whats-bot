const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
    const helpMessage = `
╔═━─━─━─━─━─━─━─━─━─━═╗  
*👑 𝗘𝗟𝗚𝗥𝗔𝗡𝗗𝗘 𝗠𝗢𝗨𝗡𝗜𝗥 𝗕𝗢𝗧 👑*  
*💠 𝗩𝗲𝗿𝘀𝗶𝗼𝗻: 𝟯.𝟬.𝟬 | 🔥 𝗣𝗼𝘄𝗲𝗿𝗲𝗱 𝗯𝘆 𝗘𝗟𝗚𝗥𝗔𝗡𝗗𝗘*  
╚═━─━─━─━─━─━─━─━─━─━═╝  

━━━✦❖✦━━━ « *🌐 الأوامر العامة* » ━━━✦❖✦━━━  
*◇ .مساعدة / .قائمة — عرض الأوامر*  
*◇ .تست ✅ — اختبار البوت*  
*◇ .نطق <نص> 🔊 — تحويل نص إلى صوت*  
*◇ .اعترف 📝 — لعبة اعترافات*  
*◇ .تخيل <وصف> 🎨 — توليد صورة*  
*◇ .مين_الوسيم 😎 — من هو الوسيم؟*  
*◇ .تزوج 💍 / .زوجتي 💞 — أوامر الزواج*  
*◇ .طلاق 💔 — إنهاء العلاقة*  
*◇ .trt <نص> <لغة> 🌐 — ترجمة*  

━━━❖☥❖━━━ « *👮‍♂️ أوامر الإدارة* » ━━━❖☥❖━━━  
*▣ .طرد @user — طرد عضو*  
*▣ .حظر @user — حظر عضو*  
*▣ .ترقية / .خفض — تعديل الرتبة*  
*▣ .كتم <دقائق> — كتم مؤقت*  
*▣ .الغاء_كتم — إلغاء الكتم*  
*▣ .بلوك / .الغاء_بلوك — حظر/إلغاء_حظر*  
*▣ .فخ 🎯 — فخ الطرد*  
*▣ .تغيير_رابط — تغيير رابط المجموعة*  
*▣ .ترحيب on/off — تفعيل الترحيب*  
*▣ .توديع on/off — تفعيل التوديع*  
*▣ .منع_رابط / .منع_كلمات — الحماية*  
*▣ .ضع_وصف <وصف> — وصف المجموعة*  
*▣ .ضع_اسم <اسم جديد> — تغيير الاسم*  
*▣ .ضع_صورة (رد على صورة)__صورة المجموعة*  
*▣ .اعضاء — عدد الأعضاء*  
*▣ .مخفي <رسالة> 👻 — رسالة سرية*  

━━━✦★✦━━━ « *💞 أوامر العلاقات* » ━━━✦★✦━━━  
*➤ .تزوج @ — طلب زواج*  
*➤ .زوجتي — من هي زوجتك؟*  
*➤ .طلاق — إنهاء العلاقة*
*➤ .احضن @ — حضن رقمي*  

━━━✦☆✦━━━ « *🎨 الصور والستيكرات* » ━━━✦☆✦━━━  
*◉ .ستيكر (رد على صورة)*  
*◉ .لصورة (رد على ستيكر)*  
*◉ .تغشيم / .قص / .مزج*  
*◉ .remini — تحسين الصورة*  
*◉ .حذف_خلفية — إزالة الخلفية*  

━━━✦✧✦━━━ « *🤖 الذكاء الاصطناعي* » ━━━✦✧✦━━━  
*🧠 .gpt / .gemini — دردشة ذكية*  
*🧠 .ابتكر / .تخيل — توليد محتوى*  
*🧠 .sora — خيال رقمي*  

━━━✦✱✦━━━ « *📥 التحميلات* » ━━━✦✱✦━━━  
*♦ .تشغيل / .اغنية — أغاني 🎵*  
*♦ .يوتيوب / .فيديو — فيديوهات 🎬*  
*♦ .انستغرام / .فيسبوك / .تيك_توك — روابط 📲*  

━•◈•━━━━━━━━━━━━━━━━━━━━•◈•━  
✨ *استمتع بأقوى بوت عربي...*`;

try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        
        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {

newsletterName: '∆§Elgrande mounir§∆',
                        serverMessageId: -1
                    }
                }
            },{ quoted: message });
        } else {
            console.error('Bot image not found at:', imagePath);
            await sock.sendMessage(chatId, { 
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {

                        newsletterName: '∆§Elgrande mounir§∆',
                        serverMessageId: -1
                    } 
                }
            });
        }
    } catch (error) {
        console.error('Error in help command:', error);
        await sock.sendMessage(chatId, { text: helpMessage });
    }
}

module.exports = helpCommand;