
async function handleNinjaInvite(sock, msg) {

    const chatId = msg.key.remoteJid;
        const inviteMessage = `
*⛩️🔥 ──❖【عــالــم الـنـيـنـجــا】❖── 🔥⛩️*
*❖ هل تملك شجاعة "ناروتو"؟* *❖ أو قوة "مادارا"؟* *❖ أم ذكاء "كاكاشي"؟*
*⛓️ إذًا مكانك بيننا!*

*🌀 أهلاً بك في عالم الشينوبي حيث لا مكان للضعفاء!* *💢 هنا المعارك بالكلمات، والاحترام هو الشرف 💢*

*⚔️ انضم الآن وأطلق العنان للتشاكرا داخلك ⚔️*

🔗 *رابط الدعوة نحو ساحة المعركة:* ~*https://chat.whatsapp.com/C5NhhgbINDa2ksz9p9uJO1?mode=hqrt1*~

*👊 كن مستعدًا، فـكل يوم تحدي جديد…* *🎌 عشيرة RAGNAROK تنتظر بطلها القادم!*
*🔥 لا تنسى… النينجا الحقيقي لا ينسحب أبداً 🔥*
*──────❖⛩️ 𝙍𝘼𝙂𝙉𝘼𝙍𝙊𝙆 ⛩️❖──────*
        `;

        

        await sock.sendMessage(chatId, { text: inviteMessage }, { quoted: msg });
}

module.exports = { handleNinjaInvite };