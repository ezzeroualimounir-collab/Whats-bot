const fs = require('fs');

const PMBLOCKER_PATH = './data/pmblocker.json';

function readState() {
    try {
        if (!fs.existsSync(PMBLOCKER_PATH)) return { enabled: false, message: '*⚠️ الرسائل في الخاصة محظورة سيتم حظرك تحدث مع المالك في مجموعة*.' };
        const raw = fs.readFileSync(PMBLOCKER_PATH, 'utf8');
        const data = JSON.parse(raw || '{}');
        return {
            enabled: !!data.enabled,
            message: typeof data.message === 'string' && data.message.trim() ? data.message : '*⚠️ الرسائل في الخاصة محظورة سيتم حظرك تحدث مع المالك في مجموعة*.'
        };
    } catch {
        return { enabled: false, message: '*⚠️ الرسائل في الخاصة محظورة سيتم حظرك تحدث مع المالك في مجموعة*.' };
    }
}

function writeState(enabled, message) {
    try {
        if (!fs.existsSync('./data')) fs.mkdirSync('./data', { recursive: true });
        const current = readState();
        const payload = {
            enabled: !!enabled,
            message: typeof message === 'string' && message.trim() ? message : current.message
        };
        fs.writeFileSync(PMBLOCKER_PATH, JSON.stringify(payload, null, 2));
    } catch {}
}

async function pmblockerCommand(sock, chatId, message, args) {
    const argStr = (args || '').trim();
    const [sub, ...rest] = argStr.split(' ');
    const state = readState();

    if (!sub || !['on', 'off', 'status', 'setmsg'].includes(sub.toLowerCase())) {
        await sock.sendMessage(chatId, { text: '*يجب اختيار وضع في امر منع الرسائل الخاصة اختر on او off واضف رسالة تحذير عبر كتابة الامر وبعده set*' }, { quoted: message });
        return;
    }

    if (sub.toLowerCase() === 'status') {
        await sock.sendMessage(chatId, { text: `امر منع رسائل الخاص  *${state.enabled ? 'ON' : 'OFF'}*\nرسالة: ${state.message}` }, { quoted: message });
        return;
    }

    if (sub.toLowerCase() === 'set') {
        const newMsg = rest.join(' ').trim();
        if (!newMsg) {
            await sock.sendMessage(chatId, { text: 'استخدم: .خاص set <رسالة>' }, { quoted: message });
            return;
        }
        writeState(state.enabled, newMsg);
        await sock.sendMessage(chatId, { text: 'تم تحديث رسالة منع الرسائل الخاصة.' }, { quoted: message });
        return;
    }

    const enable = sub.toLowerCase() === 'on';
    writeState(enable);
    await sock.sendMessage(chatId, { text: `منع الرسائل الخاصة الآن *${enable ? 'مفعل' : 'مطفئ'}*.` }, { quoted: message });
}

module.exports = { pmblockerCommand, readState };


