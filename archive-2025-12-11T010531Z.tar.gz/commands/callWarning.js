const fs = require('fs');

const path = './data/warnings.json';

// تحميل الإنذارات من الملف

function loadWarnings() {

  if (fs.existsSync(path)) {

    return JSON.parse(fs.readFileSync(path));

  }

  return {};

}

// حفظ الإنذارات في الملف

function saveWarnings(data) {

  fs.writeFileSync(path, JSON.stringify(data, null, 2));

}

// التعامل مع حدث المكالمة

async function handleCall(sock, callEvent) {

  const { from, groupJid, isvideo } = callEvent;
const id = groupJid;
  // تجاهل المكالمات في الخاص

  if (!id.endsWith('@g.us')) return;

  const warnings = loadWarnings();

  if (!warnings[id]) warnings[id] = {};

  if (!warnings[id][from]) warnings[id][from] = 0;

  warnings[id][from]++;

  saveWarnings(warnings);

  // إرسال إنذار

  await sock.sendMessage(id, { text: `@${from.split('@')[0]}، لقد تم تحذيرك بسبب المكالمة غير الضرورية.`,
    mentions : [from]                         });

  // فحص الحد الأقصى

  if (warnings[id][from] >= 3) {

    // طرد العضو

    await sock.groupParticipantsUpdate(id, [from], 'remove');

    await sock.sendMessage(id, { text: `@${from.split('@')[0]} تم طرده بسبب المكالمات المتكررة`,
 mentions : [from]

});

      
  }

}

module.exports = { handleCall };