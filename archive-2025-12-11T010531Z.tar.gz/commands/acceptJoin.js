const acceptJoin = async (sock, message) => {

  const groupJid = message.key.remoteJid;

  try {

    const requests = await sock.groupRequestParticipantsList(groupJid);

    if (!requests || requests.length === 0) {

      await sock.sendMessage(groupJid, { text: '❌ لا توجد طلبات انضمام حالياً.' }, { quoted: message });

      return;

    }

    const allJIDs = requests.map(req => req.jid);

    await sock.groupRequestParticipantsUpdate(groupJid, allJIDs, 'approve');

    await sock.sendMessage(groupJid, {

      text: `✅ تم قبول جميع الطلبات (${allJIDs.length}) بنجاح.`,

      mentions: allJIDs

    }, { quoted: message });

  } catch (err) {

    console.error('❌ خطأ أثناء قبول الطلبات:', err);

    await sock.sendMessage(groupJid, { text: '⚠️ حدث خطأ أثناء قبول الطلبات.', quoted: message });

  }

};

module.exports = { acceptJoin };