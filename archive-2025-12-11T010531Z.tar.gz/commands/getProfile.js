const getProfile = async (sock, message) => {

  try {

    const { key: { remoteJid: groupId } } = message;

    const mentioned = message.message?.extendedTextMessage?.contextInfo?.mentionedJid;

    if (!groupId.endsWith('@g.us') || !mentioned?.length) {

      await sock.sendMessage(groupId, {

        text: '❌ منشن الشخص المطلوب بهذا الشكل:\n\n@الرقم .بروفايل'

      }, { quoted: message });

      return;

    }

    const [targetJid] = mentioned;

    const ppUrl = await sock.profilePictureUrl(targetJid, 'image').catch(() => null);

    const name = targetJid.split('@')[0];

    const caption = `⚡━━━━━⚡🩸⚡━━━━━⚡
💠 *_~المنشن :~_* 
@${name}
💠 *_~الإسم :~_*
> @${name}
⚡━━━━━⚡🩸⚡━━━━━⚡`;

    const payload = ppUrl 

      ? { image: { url: ppUrl }, caption, mentions: [targetJid] }

      : { text: caption, mentions: [targetJid] };

    await sock.sendMessage(groupId, payload, { quoted: message });

  } catch (err) {

    console.error('❌ خطأ:', err);

    await sock.sendMessage(message.key.remoteJid, {

      text: '❌ لم أتمكن من جلب بروفايله.'

    }, { quoted: message });

  }

};

module.exports = getProfile;