const { toggleCallSystem } = require('./callWarning');

async function isAdmin(sock, chatId, sender) {

  const metadata = await sock.groupMetadata(chatId);

  const admins = metadata.participants.filter(p => p.admin !== null).map(p => p.id);

  return admins.includes(sender);

}

async function enableCallBlock(sock, msg) {

  const chatId = msg.key.remoteJid;

  const sender = msg.key.participant || msg.key.remoteJid;

  if (!(await isAdmin(sock, chatId, sender))) {

    return sock.sendMessage(chatId, {

      text: '❌ هذا الأمر متاح فقط لمشرفي المجموعة.'

    }, { quoted: msg });

  }

  toggleCallSystem(chatId, true);

  await sock.sendMessage(chatId, {

    text: '✅ تم تفعيل نظام منع المكالمات.'

  }, { quoted: msg });

}

async function disableCallBlock(sock, msg) {

  const chatId = msg.key.remoteJid;

  const sender = msg.key.participant || msg.key.remoteJid;

  if (!(await isAdmin(sock, chatId, sender))) {

    return sock.sendMessage(chatId, {

      text: '❌ هذا الأمر متاح فقط لمشرفي المجموعة.'

    }, { quoted: msg });

  }

  toggleCallSystem(chatId, false);

  await sock.sendMessage(chatId, {

text: '❎ تم إيقاف نظام منع المكالمات.'

  }, { quoted: msg });

}

module.exports = {

  enableCallBlock,

  disableCallBlock

};