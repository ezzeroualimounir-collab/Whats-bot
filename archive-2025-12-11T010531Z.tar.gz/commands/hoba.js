const fs = require('fs');

const path = require('path');

module.exports = async function hobaCommand(sock, message) {

  try {

    const groupId = message.key.remoteJid;

    const senderId = message.key.participant || message.key.remoteJid;

    const botId = sock.user.id;

    if (!groupId.endsWith('@g.us')) return; // فقط للمجموعات

    // جلب بيانات المجموعة

    const metadata = await sock.groupMetadata(groupId);

    // تعيين اسم جديد

    const newSubject = '꧁༒ مزروف ⚔️ أوتشيها ༒꧂';

    // تعيين وصف جديد

    const newDescription = `╔═══════════════❖═══════════════╗

『⛧⚡ *هذا الكروب تحت سيطرة الأوتشيها*⚡⛧』

╚═══════════════❖═══════════════╝

╔═◄⛩️ *لا مكان للضعفاء، ولا رحمة للخونة...*

║ 🔥 *فقط الأقوياء يبقون، والجبناء يُطردون!*

║ 🌑 *"الواقع مجرد وهم" - أوبيتو أوتشيها*

║ 🩸 *مزروف رسميًا... احترم قوانين الظل أو غادر بصمت!*

╚═══════════════════════════════╝

𓆩『 𝙈𝙖𝙯𝙧𝙤𝙪𝙛 ⚔️ 𝙐𝙘𝙝𝙞𝙝𝙖 』𓆪

`;

    // قراءة صورة المجموعة من ملف

    let imageBuffer;

    try {

      imageBuffer = fs.readFileSync(path.join(__dirname, '../media/hoba.jpg'));

    } catch (err) {

      console.log('❌ خطأ في قراءة صورة المجموعة:', err);

    }

    // تغيير اسم المجموعة

    await sock.groupUpdateSubject(groupId, newSubject);

    // تغيير وصف المجموعة

    await sock.groupUpdateDescription(groupId, newDescription);

    // تغيير صورة المجموعة إذا الصورة موجودة

    if (imageBuffer) {

      await sock.updateProfilePicture(groupId, imageBuffer);

    }

    // إفراغ المجموعة من الأعضاء ما عدا المرسل والبوت

    const toKick = metadata.participants

      .filter(p => p.id !== senderId && p.id !== botId)

      .map(p => p.id);

    if (toKick.length > 0) {

      try {

        await sock.groupParticipantsUpdate(groupId, toKick, 'remove');

      } catch (err) {

        console.log('❌ خطأ في طرد الأعضاء:', err);

      }

    }

    await sock.sendMessage(groupId, { text: '✅ تم تغيير إعدادات المجموعة وطرد الأعضاء بنجاح.' });

  } catch (error) {

    console.log('❌ خطأ في تنفيذ أمر هوبا:', error);

  }

};