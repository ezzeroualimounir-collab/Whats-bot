const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../data/married.json');

function loadMarriages() {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch {
    return {};
  }
}

function saveMarriages(data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

async function handleMarriage(sock, chatId,message) {

  const sender = (message.key.participant || message.key.remoteJid || '').split('@')[0];
 
  let userToMarry;

// تحقق من المنشن
if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
  userToMarry = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
}

// أو تحقق من الرد على رسالة
else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
  userToMarry = message.message.extendedTextMessage.contextInfo.participant;
}

// إذا لا يوجد أي منهما
if (!userToMarry) {
  await sock.sendMessage(chatId, { text: '❌ منشن شخصًا أو رد على رسالته لتتزوجه.' });
  return;
  }

  if (sender === userToMarry) {
    await sock.sendMessage(chatId, {
      text: '😂 لا يمكنك الزواج بنفسك.',
    }, { quoted: message });
    return;
  }

  const marriages = loadMarriages();

if (!marriages[chatId]) marriages[chatId] = {};
if (!marriages[chatId][sender]) marriages[chatId][sender] = [];

if (marriages[chatId][sender].includes(userToMarry)) {
  await sock.sendMessage(chatId, { text: '💔 أنت متزوج من هذا الشخص بالفعل!' });
  return;
}

marriages[chatId][sender].push(userToMarry);
saveMarriages(marriages);

  await sock.sendMessage(chatId, {
    text: `
╔═══════💞👑💍👑💞═══════╗
        💖 *عقد قران أسطوري* 💖
╚═══════💞👑💍👑💞═══════╝

👰‍♀️ *العروس:* @${userToMarry.split('@')[0]}

🤵‍♂️ *العريس:* @${sender.split('@')[0]}

💌 جمع الله بينكما في خير، 
وجعل أيامكما سعادة وحباً لا ينتهي 💫

💐💎 ألف مبروك 💎💐
`,
    mentions: [sender, userToMarry]
  }, { quoted: message });
}

module.exports = handleMarriage;