// spam.js

async function handleSpam(sock, msg) {

  try {

    const text = msg.message.conversation || msg.message.extendedTextMessage?.text;

    const args = text.split(' ');

    const count = parseInt(args[1]);

    if (isNaN(count) || count <= 0) {

      await sock.sendMessage(msg.key.remoteJid, { text: 'الرجاء إدخال عدد صحيح للسبام' });

      return;

    }

    if (msg.message.extendedTextMessage && msg.message.extendedTextMessage.contextInfo && msg.message.extendedTextMessage.contextInfo.quotedMessage) {

      const quotedMessage = msg.message.extendedTextMessage.contextInfo.quotedMessage;

      if (quotedMessage.imageMessage) {

        const media = {

          image: await downloadMediaMessage(quotedMessage),

          caption: quotedMessage.imageMessage.caption

        };

        for (let i = 0; i < count; i++) {

          await sock.sendMessage(msg.key.remoteJid, media);

        }

      } else if (quotedMessage.videoMessage) {

        const media = {

          video: await downloadMediaMessage(quotedMessage),

          caption: quotedMessage.videoMessage.caption

        };

        for (let i = 0; i < count; i++) {

          await sock.sendMessage(msg.key.remoteJid, media);

        }

      } else if (quotedMessage.stickerMessage) {

        const media = {

          sticker: await downloadMediaMessage(quotedMessage)

        };

        for (let i = 0; i < count; i++) {

          await sock.sendMessage(msg.key.remoteJid, media);

        }

      } else {

        const quotedText = quotedMessage.conversation || quotedMessage.extendedTextMessage?.text;

        for (let i = 0; i < count; i++) {

          await sock.sendMessage(msg.key.remoteJid, { text: quotedText });

        }

      }

    } else {

      const spamText = args.slice(2).join(' ');

      for (let i = 0; i < count; i++) {

        await sock.sendMessage(msg.key.remoteJid, { text: spamText });

      }

    }

  } catch (err) {

    console.error('❌ خطأ في handleSpam:', err);

  }

}

module.exports = { handleSpam };