const settings = require('../settings');

const fs = require('fs');

const path = require('path'); 

async function helpCommand(sock, chatId, message) {

    const helpMessage = `

╔═─═─═─═─═─═─═─═─═─═─═╗  
  🌑 🩸 ~*_NARUTO_*~ 🩸 🌑  
╚═─═─═─═─═─═─═─═─═─═─═╝  
◇━━━━━━━📃━━━━━━◇  
              ✨ *الأوامر العامة* ✨  
◇━━━━━━━⚡━━━━━━◇  
> 🩸 *_.مساعدة / .قائمة_*🩸

> ⚡ *_.تست_*⚡

> 🩸 *_.نطق <نص>_*🩸  

> ⚡ *_.مطور_*⚡  

> 🩸 *_.كلمات <اسم>_*🩸  

> ⚡ *_.عرض <صورة>_*⚡   

> 🩸 *_اكتب .trt  للترجمة_*🩸
◇━━━━━━━⚡🩸⚡━━━━━━◇
       🛡️ *أوامر الإدارة* 🛡️
◇━━━━━━━⚡🩸⚡━━━━━━◇  
> ⚡ *_.حظر @عضو_* ⚡ 

> 🩸 *_.ترقية @عضو_*🩸  

> ⚡ *_.خفض @عضو_*⚡  

> 🩸 *_.كتم <دقائق>_*🩸 

> ⚡ *_.الغاء_كتم_*⚡ 

> 🩸 *_.حذف <عدد>_* 🩸 

> ⚡ *_.طرد @عضو_*⚡
◇━━━━━━━⚡🩸⚡━━━━━━◇

◇━━━━━━━⚡🩸⚡━━━━━━◇
> ⚡ *_.تحذيرات @عضو_*⚡  

> 🩸 *_.تحذير @عضو_*🩸 

> ⚡ *_.منع_رابط on/off_*⚡

> 🩸 *_.فاحش/.الغاء_فاحش_*🩸 

> ⚡ *_.تنظيف_*⚡  

> 🩸 *_.طاغي_*🩸
◇━━━━━━━⚡🩸⚡━━━━━━◇ 

◇━━━━━━━⚡🩸⚡━━━━━━◇
> ⚡ *_.اعضاء_*⚡ 

> 🩸 *_.مخفي <رسالة>_*🩸  

> ⚡ *_.تغيير_رابط_*⚡ 

> 🩸 *_.منع_منشن <on/off>_*🩸 

> ⚡ *_.ترحيب <on/off>_*⚡  

> 🩸 *_.توديع <on/off>_*🩸 

> ⚡ *_.ضع_وصف <الوصف>_*⚡ 

> 🩸 *_.ضع_اسم <الاسم>_*🩸 

> ⚡ *_.ضع_صورة_*⚡
◇━━━━━━━⚡🩸⚡━━━━━━◇  
     🎨 *أوامر الصور والستيكرز* 🎨  
     ⚠️ *_رد على صورة/ ملصق_*
◇━━━━━━━⚡🩸⚡━━━━━━◇
> 🩸 *_.تغشيم <صورة>_*🩸 

> ⚡ *_.لصورة_*⚡

> 🩸 *_.ستيكر_*🩸 

> ⚡ *_.حذف_خلفية_*⚡ 

> 🩸 *_اكتب .remini_*🩸 

> ⚡ *_.قص_*⚡  

> 🩸 *_.مزج <1>+<2>_*🩸  
◇━━━━━━━⚡🩸⚡━━━━━━◇ 
      🤖 *أوامر الذكاء الاصطناعي* 🤖  
◇━━━━━━⚡🩸⚡━━━━━━◇
> 🧠 *_اكتب  .gpt <سؤال>_*🧠  

> ⚡ *_اكتب .gemini <سؤال>_*⚡ 

> 🧠 *_.تخيل <وصف>_*🧠 

> ⚡ *_.ابتكر <وصف>_*⚡ 

> 🧠 *_اكتب .sora_*🧠
◇━━━━━━━⚡🩸⚡━━━━━━◇  
            ⬇️ *أوامر التنزيل* ⬇️  
◇━━━━━━━⚡🩸⚡━━━━━━◇
> 🎵 _*.تشغيل* —  أغنية_🎵

> ⚡ _*.اغنية* —  أغنية_⚡

> ⚡📸 *_.انستغرام <رابط_*⚡ 

> 🩸📘 *_.فيسبوك <رابط>_* 🩸 

> ⚡ *_.تيك_طوك <رابط>_*⚡  

> 🩸 *_.فيديو <اسم_الأغنية>_*🩸 

> ⚡ *_.يوتيوب <رابط>_*⚡  
⚡━━━━━━━⚡🩸⚡━━━━━━⚡
> *_~Created By : ★彡『𝔈𝔩𝔤𝔯𝔞𝔫𝔡𝔢 .𝔪𝔬𝔲𝔫𝔦𝔯』彡★~_*
⚡━━━━━━━⚡🩸⚡━━━━━━⚡
> *_~Official Group :~_*

https://chat.whatsapp.com/I7TA0VvyTKp9w3Hz2WNTAk?mode=hqrt1
⚡━━━━━━━⚡🩸⚡━━━━━━⚡`; 

try {

        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');

        

        if (fs.existsSync(imagePath)) {

            const imageBuffer = fs.readFileSync(imagePath);

            

            await sock.sendMessage(chatId, {

                image: imageBuffer,

                caption: helpMessage,

                contextInfo: {

                    forwardingScore: 1,

                    isForwarded: true,

                    forwardedNewsletterMessageInfo: { 

newsletterName: '∆§Elgrande mounir§∆',

                        serverMessageId: -1

                    }

                }

            },{ quoted: message });

        } else {

            console.error('Bot image not found at:', imagePath);

            await sock.sendMessage(chatId, { 

                text: helpMessage,

                contextInfo: {

                    forwardingScore: 1,

                    isForwarded: true,

                    forwardedNewsletterMessageInfo: { 

                        newsletterName: '∆§Elgrande mounir§∆',

                        serverMessageId: -1

                    } 

                }

            });

        }

    } catch (error) {

        console.error('Error in help command:', error);

        await sock.sendMessage(chatId, { text: helpMessage });

    } 

const audioPath = path.join(__dirname,'media','help.opus'); 

      if (fs.existsSync(audioPath)) { 

        await sock.sendMessage(chatId, { 

          audio: { url: audioPath }, 

          mimetype: 'audio/mp4',

ptt:true

        }, { quoted: message }); 

      } else { 

        console.log('ملف الصوت غير موجود'); 

      }

}

     

module.exports = helpCommand;