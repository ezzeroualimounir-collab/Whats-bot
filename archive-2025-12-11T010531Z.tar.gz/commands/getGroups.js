const fs = require('fs');

const path = require('path');

const filePath = path.join(__dirname, '../data/groups.json');

async function getGroups(sock, message) {

  try {

    const groups = await sock.groupFetchAllParticipating();

    const groupList = Object.values(groups);

    const data = groupList.map(g => ({

      id: g.id,

      name: g.subject

    }));

    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');

    let text = `╔═─═─═─═─═─═─═─═─═─═─═╗  
🩸 *⚡قائمة المجموعات التي يشارك فيها البوت:*🩸 
 ╚═─═─═─═─═─═─═─═─═─═─═╝
◇━━━━━━━🩸📃🩸━━━━━━◇
`;

    data.forEach((g, i) => {

   text += `*${i + 1}*.${g.name}\n`;

    });

    text += '◇━━━━━━━⚡🩸⚡━━━━━━◇ ';

    await sock.sendMessage(message.key.remoteJid, { text });

  } catch (err) {

    console.error('❌ خطأ:', err);

    await sock.sendMessage(message.key.remoteJid, { text: '⚠️ وقع خطأ أثناء جلب المجموعات.' });

  }

}

module.exports = {getGroups};