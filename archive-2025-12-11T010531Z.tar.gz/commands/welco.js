const welcome = async (sock, message) => {

  try {

    const { key: { remoteJid: groupId } } = message;

    const mentioned = message.message?.extendedTextMessage?.contextInfo?.mentionedJid;

    if (!groupId.endsWith('@g.us') || !mentioned?.length) {

      await sock.sendMessage(groupId, {

        text: '❌ منشن الشخص المطلوب بهذا الشكل:\n\n@الرقم .ترحيب'

      }, { quoted: message });

      return;

    }

    const [targetJid] = mentioned;

    const ppUrl = await sock.profilePictureUrl(targetJid, 'image').catch(() => null);

    const groupMetadata = await sock.groupMetadata(groupId);

    const groupName = groupMetadata.subject;

    const caption = `
*༺═──────── 👑 ────────═༻*
   *⚜️ ترحيبٌ ملكيٌ بنجمٍ جديد ⚜️*
 *༺═─────── 💖 ───────═༻*
*┏━━━━━━━━━━━━━━━━━━━━━┓*
 ┃ ✨ *أَهْلَاً بِالنَّجْمِ الـمُشْرِق:* @${mentioned}
 ┃ 🏰 *فِي قَصْرِنَا الـفَاخِر:* *${groupName}*
 ┃
 ┃ 🌹 *تَشْرِيفُكَ لَنَا زَادَنَا بَهْجَةً وَسُرُورَا.*
 ┃ 🌟 *نَتَمَنَّى لَكَ إِقَامَةً مُمْتِعَةً وَمِلْؤُهَا النَّشَاط.*
*┗━━━━━━━━━━━━━━━━━━━━━┛*
*💫 لِتَكُنْ أَوَّلَ المُتَأَلِّقِينَ!*`;

    if (ppUrl) {

      await sock.sendMessage(groupId, { image: { url: ppUrl }, caption, mentions: mentioned });

    } else {

      await sock.sendMessage(groupId, { text: caption, mentions: mentioned });

    }

  } catch (err) {

    console.error('❌ خطأ:', err);

  }

};

module.exports = welcome;