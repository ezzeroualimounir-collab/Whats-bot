const fs = require('fs');

const path = require('path');

const mutedFile = path.join(__dirname, '../data/muted.json');

let muted = fs.existsSync(mutedFile) ? JSON.parse(fs.readFileSync(mutedFile)) : {};

async function handleMuteCommand(sock, msg) {

  const chatId = msg.key.remoteJid;
const groupMetadata = await sock.groupMetadata(chatId);

const senderId = msg.key.participant || msg.key.remoteJid;

const isAdmin = groupMetadata.participants.some(p =>

  p.id === senderId && (p.admin === 'admin' || p.admin === 'superadmin')

);

if (!isAdmin) {

  await sock.sendMessage(chatId, {

    text: '❌ هذا الأمر خاص بالمشرفين فقط.',

  }, { quoted: msg });

  return;

}
  const quoted = msg.message?.extendedTextMessage?.contextInfo?.participant;

  if (!quoted) {

    await sock.sendMessage(chatId, { text: '❌ يجب الرد على رسالة العضو الذي تريد كتمه.' }, { quoted: msg });

    return;

  }

  if (!muted[chatId]) muted[chatId] = [];

  if (!muted[chatId].includes(quoted)) {

    muted[chatId].push(quoted);

    fs.writeFileSync(mutedFile, JSON.stringify(muted, null, 2));

  }

  await sock.sendMessage(chatId, { text: `🔇 تم كتم  @${quoted.split('@')[0]} بنجاح.` }, { quoted: msg, mentions: [quoted] });

}

module.exports = { handleMuteCommand };