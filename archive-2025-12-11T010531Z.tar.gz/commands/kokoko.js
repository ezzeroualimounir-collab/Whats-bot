const fs = require('fs');

const path = require('path');

const mutedPath = path.join(__dirname, '../data/muted.json');

function loadMuted() {

  if (!fs.existsSync(mutedPath)) return [];

  return JSON.parse(fs.readFileSync(mutedPath, 'utf8'));

}

function saveMuted(muted) {

  fs.writeFileSync(mutedPath, JSON.stringify(muted, null, 2));

}

async function handleMuteCommand(sock, msg) {

  const chatId = msg.key.remoteJid;

  // التحقق من أن الرسالة في مجموعة

  if (!chatId.endsWith('@g.us')) return;

  // التحقق من أن المرسل أدمن

  const metadata = await sock.groupMetadata(chatId);

  const sender = msg.key.participant || msg.key.remoteJid;

  const isAdmin = metadata.participants.some(p => p.id === sender && (p.admin === 'admin' || p.admin === 'superadmin'));

  if (!isAdmin) {

    await sock.sendMessage(chatId, { text: '❌ هذا الأمر مخصص للمشرفين فقط.' }, { quoted: msg });

    return;

  }

  // التحقق من وجود رد على رسالة

  const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;

  if (!quotedParticipant) {

await sock.sendMessage(chatId, { text: '❌ من فضلك قم بالرد على رسالة العضو الذي تريد كتمه.' }, { quoted: msg });

    return;

  }

  let muted = loadMuted();

  if (!muted.includes(quotedParticipant)) {

    muted.push(quotedParticipant);

    saveMuted(muted);

    await sock.sendMessage(chatId, {

      text: `🔇 تم كتم @${quotedParticipant.split('@')[0]}`,

      mentions: [quotedParticipant]

    });

  } else {

    await sock.sendMessage(chatId, { text: 'ℹ️ هذا العضو مكتوم بالفعل.' }, { quoted: msg });

  }

}

module.exports = { handleMuteCommand };