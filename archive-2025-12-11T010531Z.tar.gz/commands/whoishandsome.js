async function handleWhoIsHandsome(sock, chatId, msg) {

  const groupMetadata = await sock.groupMetadata(chatId);

  const participants = groupMetadata.participants;

  if (!participants || participants.length === 0) {

    return sock.sendMessage(chatId, { text: '❌ لا يوجد أعضاء في هذه المجموعة.' }, { quoted: msg });

  }

  const randomIndex = Math.floor(Math.random() * participants.length);

  const handsomeGuy = participants[randomIndex].id;

  const message = `👑 وسيم المجموعة اليوم هو:\n\n@${handsomeGuy.split('@')[0]} 😎🔥`;

  await sock.sendMessage(chatId, {

    text: message,

    mentions: [handsomeGuy],

  }, { quoted: msg });

}

module.exports = { handleWhoIsHandsome };