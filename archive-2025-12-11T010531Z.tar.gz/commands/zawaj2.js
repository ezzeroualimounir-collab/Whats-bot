const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../data/married.json');

function loadMarriages() {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch {
    return {};
  }
}

function saveMarriages(data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

async function handleMarriage(sock, chatId,message) {

  const sender = (message.key.participant || message.key.remoteJid || '').split('@')[0];
 const messageText = message.message.conversation || message.message.extendedTextMessage?.text || '';

  const args = messageText.trim().split(/\s+/).slice(1);
    
  let target = null;

// منشن مباشر
if (
  message.message?.extendedTextMessage?.contextInfo?.mentionedJid &&
  message.message.extendedTextMessage.contextInfo.mentionedJid.length > 0
) {
  target = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
}

// رد على رسالة
else if (
  message.message?.extendedTextMessage?.contextInfo?.participant
) {
  target = message.message.extendedTextMessage.contextInfo.participant;
}

// رقم يدوي
else if (args.length > 0) {
  const number = args[0].replace(/\D/g, '');
  if (number) {
    target = number + '@s.whatsapp.net';
  }
}

// لم يتم تحديد شخص
if (!target) {
  await sock.sendMessage(chatId, {
    text: '❌ يرجى منشن الشخص، الرد عليه أو كتابة رقمه بعد الأمر.',
  }, { quoted: message });
  return;
}

  if (target.includes(sender)) {
    await sock.sendMessage(chatId, {
      text: '😂 لا يمكنك الزواج بنفسك.',
    }, { quoted: message });
    return;
  }

  const marriages = loadMarriages();

if (!marriages[chatId]) marriages[chatId] = {};
if (!marriages[chatId][sender]) marriages[chatId][sender] = [];

if (marriages[chatId][sender].includes(target)) {
  await sock.sendMessage(chatId, { text: '💔 أنت متزوج من هذا الشخص بالفعل!' });
  return;
}

marriages[chatId][sender].push(target);
saveMarriages(marriages);

  await sock.sendMessage(chatId, {
    text: `
╔═══════💞👑💍👑💞═══════╗
        💖 *عقد قران أسطوري* 💖
╚═══════💞👑💍👑💞═══════╝

👰‍♀️ *العروس:* @${target.split('@')[0]}

🤵‍♂️ *العريس:* @${sender.split('@')[0]}

💌 جمع الله بينكما في خير، 
وجعل أيامكما سعادة وحباً لا ينتهي 💫

💐💎 ألف مبروك 💎💐
`,
    mentions: [sender, target]
  }, { quoted: message });
}

module.exports = handleMarriage;