const fs = require('fs');

const path = require('path');

// المسارات

const badwordsPath = path.join(__dirname, '../data/badwords.json');

const settingsPath = path.join(__dirname, '../data/badwordSettings.json');

const warningsPath = path.join(__dirname, '../data/wordwarnings.json');

// تحميل البيانات

const badwords = JSON.parse(fs.readFileSync(badwordsPath));

let settings = fs.existsSync(settingsPath) ? JSON.parse(fs.readFileSync(settingsPath)) : {};

let warnings = fs.existsSync(warningsPath) ? JSON.parse(fs.readFileSync(warningsPath)) : {};

function saveSettings() {

  fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

}

function saveWarnings() {

fs.writeFileSync(warningsPath, JSON.stringify(warnings, null, 2));

}

// التفعيل / الإلغاء

async function toggleBadwords(sock, chatId, enable) {

  settings[chatId] = enable;

  saveSettings();

  const msg = enable ? '✅ تم تفعيل منع الكلمات السيئة.' : '❌ تم إلغاء التفعيل.';

  await sock.sendMessage(chatId, { text: msg });

}

//الدالة الأساسية

async function handleBadwords(sock, chatId, message, text, senderId) {

  if (!settings[chatId]) return;

  const lower = text.toLowerCase();

  const found = badwords.find(word => lower.includes(word.toLowerCase()));

  if (!found) return;

  // نظام التحذيرات

  if (!warnings[chatId]) warnings[chatId] = {};

  if (!warnings[chatId][senderId]) warnings[chatId][senderId] = 0;

  warnings[chatId][senderId]++;

  saveWarnings();

  const count = warnings[chatId][senderId];

  // حذف الرسالة الأصلية

  try {

    await sock.sendMessage(chatId, {

      delete: {

        remoteJid: chatId,

        fromMe: false,

        id: message.key.id,

        participant: message.key.participant

      }

    });

  } catch (err) {

    console.log('فشل في حذف الرسالة:', err);

  }

  // إرسال تحذير مع منشن

  await sock.sendMessage(chatId, {

    text: `⚠️ @${senderId.split('@')[0]}، هذه الكلمة غير مسموحة! تحذير${count}/3`,

    mentions: [senderId]

  });

}
module.exports = {

  handleBadwords,

  toggleBadwords};