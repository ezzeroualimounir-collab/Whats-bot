const fs = require('fs');
const path = require('path');
// المسارات
const badwordsPath = path.join(__dirname, '../data/badwords.json');
const settingsPath = path.join(__dirname, '../data/badwordSettings.json');
const warningsPath = path.join(__dirname, '../data/wordwarnings.json');
// تحميل البيانات
const badwords = JSON.parse(fs.readFileSync(badwordsPath));
let settings = fs.existsSync(settingsPath) ? JSON.parse(fs.readFileSync(settingsPath)) : {};
let warnings = fs.existsSync(warningsPath) ? JSON.parse(fs.readFileSync(warningsPath)) : {};
function saveSettings() {
  fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

}

function saveWarnings() {

fs.writeFileSync(warningsPath, JSON.stringify(warnings, null, 2));

}

// التفعيل / الإلغاء

async function toggleBadwords(sock, chatId, enable) {

  settings[chatId] = enable;
  saveSettings();

  const msg = enable ? '✅ تم تفعيل منع الكلمات السيئة.' : '❌ تم إلغاء التفعيل.';

  await sock.sendMessage(chatId, { text: msg });

}

// الدالة الأساسية

async function handleBadwords(sock, chatId, message, text, senderId) {

  if (!settings[chatId]) return;
  const lower = text.toLowerCase();
  const found = badwords.find(word => lower.includes(word.toLowerCase()));

  if (!found) return;

  // تحذير

  if (!warnings[chatId]) warnings[chatId] = {};
  if (!warnings[chatId][senderId]) warnings[chatId][senderId] = 0;
  warnings[chatId][senderId]++;
  saveWarnings();
  const count = warnings[chatId][senderId];

  if (count >= 3) {

    try {

      await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');

      await sock.sendMessage(chatId, { text: `❌ تم طرد العضو لتكراره الكلمات الممنوعة.` });

    } catch (err) {

      console.log('فشل الطرد:', err);

    }
  } else {

    await sock.sendMessage(chatId, { text: `⚠️ ممنوع قول هذه الكلمة! تحذير ${count}/3` }, { quoted: message });

  }
}    
module.exports = {
  handleBadwords,
  toggleBadwords};