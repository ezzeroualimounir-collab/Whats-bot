let activeTraps = {}; // تخزين الفخاخ حسب معرف المجموعة

function isGroupJid(jid) {

  return jid.endsWith('@g.us');

}

async function setTrap(sock, chatId, msg) {

// تأكد أن الرسالة من جروب

if (!isGroupJid(chatId)) return;

// جلب معلومات المجموعة وأعضاءها

const groupMetadata = await sock.groupMetadata(chatId);

const admins = groupMetadata.participants

  .filter(p => p.admin !== null)

  .map(p => p.id);

// تحقق من أن المرسل هو أدمين

const sender = msg.key.participant || msg.key.remoteJid;

if (!admins.includes(sender)) {

  return sock.sendMessage(chatId, {

    text: '*❌ هذا الأمر متاح فقط لأدمنات المجموعة*.'

  }, { quoted: msg });

}

// استمر في تنفيذ الأمر

  if (activeTraps[chatId]) {

    return sock.sendMessage(chatId, {

      text: '*⚠️ الفخ مفعل مسبقاً في هذه المجموعة!*',

    }, { quoted: msg });

  }

  activeTraps[chatId] = true;

  await sock.sendMessage(chatId, {

    text: '*🪤 أول شخص يرسل رسالة بعد هذه سيتم طرده من المجموعة!*',

  });

  const trapHandler = async ({ messages }) => {

    const message = messages[0];

    const from = message.key.remoteJid;

    const sender = message.key.participant;

    if (from === chatId && activeTraps[chatId] && sender) {

      delete activeTraps[chatId];

      try {

await sock.sendMessage(chatId, {

          text: `*👢 تم طرد @${sender.split('@')[0]} لأنه أول من تحدث بعد الفخ!*`,

          mentions: [sender],

        });

        await sock.groupParticipantsUpdate(chatId, [sender], 'remove');

      } catch (err) {

        console.error('فشل الطرد:', err);

        await sock.sendMessage(chatId, {

          text: '❌ فشل في طرد العضو. تأكد أن البوت مشرف.',

        });

      }

      sock.ev.off('messages.upsert', trapHandler);

    }

  };

  sock.ev.on('messages.upsert', trapHandler);

  // تنظيف تلقائي بعد 5 دقائق

  setTimeout(() => {

    delete activeTraps[chatId];

    sock.ev.off('messages.upsert', trapHandler);

  }, 5 * 60 * 1000);

}

module.exports = { setTrap };