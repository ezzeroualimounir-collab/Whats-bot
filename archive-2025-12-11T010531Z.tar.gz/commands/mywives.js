const fs = require('fs');

const path = require('path');

async function handleMyWives(sock, chatId, msg) {

  try {

    // 1. استخدام المعرّف الكامل (Full JID) للبحث في ملف JSON

    const senderJidFull = msg.key.participant || msg.key.remoteJid; 

    

    // استخراج الجزء الرقمي فقط للعرض

    const senderNumber = senderJidFull.split('@')[0]; 

    const filePath = path.join(__dirname, '../data/married.json');

    if (!fs.existsSync(filePath)) {

      await sock.sendMessage(chatId, { text: '📂 لا يوجد سجل زواج بعد.' });

      return;

    }

    const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

    // 2. البحث باستخدام المعرّف الكامل (senderJidFull)

    if (!data[chatId] || !data[chatId][senderJidFull] || data[chatId][senderJidFull].length === 0) {

      await sock.sendMessage(chatId, { text: '🙁 ليس لديك زوجات في هذه المجموعة.'

                                    },{quoted: msg });

      return;

    }

    const myWives = data[chatId][senderJidFull];

    // تحويل مصفوفة الـ JIDs إلى مصفوفة نصوص للمنشن (للعرض في النص)

    const mentionsText = myWives.map(jid => `@${jid.split('@')[0]}`);

    

    // تجهيز مصفوفة الـ JIDs الكاملة لكل من الزوجات والمرسل (لتفعيل التنبيهات)

    const allMentionsJids = [...myWives, senderJidFull]; 

    const message = `
╔═══════ 💎 ═══════╗
✨ ❖━━═━═━═━━❖ ✨
*👑 إِعْـلانٌ مُـلْـكِـيٌّ خَـاص 👑*
*~زوجاتك الحاليين هن~*
> ${mentionsText.join('\n')}
✨ ❖━━═━═━═━━❖ ✨
╚═══════ 💎 ═══════╝
╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄╮
*إشراف على روح:@${senderNumber}*
╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄╯
*༺═══💘═══🕊️═══💘═══༻*
*نَتَمَنَّى لِصَاحِبِ هَذِهِ القُلُوبِ دَوَامَ الْحُبِّ وَ السَّعَادَة الأبَدِيَّة.* 🌹
`;

    // 3. استخدام contextInfo.mentionedJid لإرسال المنشن بشكل صحيح مع النص

    await sock.sendMessage(chatId, {

      text: message,

      contextInfo: { mentionedJid: allMentionsJids } 

    },{quoted: msg   });

  } catch (err) {

    console.error('🚫 خطأ في handleMyWives:', err);

    await sock.sendMessage(chatId, { text: '❌ حدث خطأ أثناء عرض الزوجات.' });

  }

}

module.exports = { handleMyWives };

