const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../data/married.json');

function loadMarriages() {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch {
    return {};
  }
}

function saveMarriages(data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

async function handleMarriage(sock, chatId,message) {

  const sender = message.key.participant || message.key.remoteJid;
 
  let target = null;

// منشن مباشر
if (
  message.message?.extendedTextMessage?.contextInfo?.mentionedJid &&
  message.message.extendedTextMessage.contextInfo.mentionedJid.length > 0
) {
  target = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
}

// رد على رسالة
else if (
  message.message?.extendedTextMessage?.contextInfo?.participant
) {
  target = message.message.extendedTextMessage.contextInfo.participant;
}

// رقم يدوي
else if (args.length > 0) {
  const number = args[0].replace(/\D/g, '');
  if (number) {
    target = number + '@s.whatsapp.net';
  }
}

// لم يتم تحديد شخص
if (!target) {
  await sock.sendMessage(chatId, {
    text: '❌ يرجى منشن الشخص، الرد عليه أو كتابة رقمه بعد الأمر.',
  }, { quoted: message });
  return;
}

  if (sender === target) {
    await sock.sendMessage(chatId, {
      text: '😂 لا يمكنك الزواج بنفسك.',
    }, { quoted: message });
    return;
  }

  const marriages = loadMarriages();

if (!marriages[chatId]) marriages[chatId] = {};
if (!marriages[chatId][sender]) marriages[chatId][sender] = [];

if (marriages[chatId][sender].includes(target)) {
  await sock.sendMessage(chatId, { text: '💔 أنت متزوج من هذا الشخص بالفعل!'
                                  
   },{quoted: message});                               



  return;
}

marriages[chatId][sender].push(target);
saveMarriages(marriages);

  await sock.sendMessage(chatId, {
    text: `
         🌹 ⊱━━━ 👑 ━━━⊰ 🌹
           *أَفْخَمُ مَرَاسِيمِ الـعِشْقِ*  
         🌹 ⊱━━━ 👑 ━━━⊰ 🌹
*بِسْمِ الـحُبِّ المُقَدَّسِ الَّذِي لَا يَزُول، وَبِعَهْدٍ أَبَدِيٍّ جَمَعَ القَلْبَيْن:*
╭━♡━━━✦━━━━━✦━━━♡━╮
          *🌹 قَـسَـمُ الـخُـلُودِ 🌹*
╰━♡━━━✦━━━━━✦━━━♡━╯

*الـمَـلِـكُ الـمُـتَـوَّج:*
*🤵@${sender.split('@')[0]}* 💖
*الـمَـلِـكَةُ الـسَّـاحِـرَة:*
*👰@${target.split('@')[0]}* 💘
*｡･ﾟ♡ﾟ･｡🌟｡･ﾟ♡ﾟ･｡*
  *🕊️ تـسـجـيـل الـعـهـد الأبـدي 🕊️*
*｡･ﾟ♡ﾟ･｡🌟｡･ﾟ♡ﾟ･｡*

*تَمَّتْ مُبَايَعَةُ الحُبِّ، وَاسْتَقَرَّتِ المَشَاعِرُ بِـالْقَدَرِ السَّعِيدِ.*
*لِيَكُنْ حُبُّكُمَا أُسْطُورَةَ تُرْوَى فِي أَرْجَاءِ هَذِهِ المَجْمُوعَة.*
*🌹💍 أَلْفُ مُبَارَكَةٍ لِقَلْبَيْنِ بَاتَا وَاحِداً 💍🌹*
`,
    mentions: [sender, target]
  }, { quoted: message });
}

module.exports = handleMarriage;