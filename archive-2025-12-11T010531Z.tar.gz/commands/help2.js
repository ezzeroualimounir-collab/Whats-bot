const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
    const helpMessage = `
╔═━━━━━◇◆◇━━━━━═╗
🔱 𝐄𝐋𝐆𝐑𝐀𝐍𝐃𝐄 𝐌𝐎𝐔𝐍𝐈𝐑 𝐁𝐎𝐓 🔱
╚═━━━━━◇◆◇━━━━━═╝

👑⌯ 𝑽𝒆𝒓𝒔𝒊𝒐𝒏: 𝟯.𝟬.𝟬 | ⚙️ 𝑩𝒚: @Elgrande mounir

╭─────────🎯─────────╮
┃ 💬 *أوامر المحادثة:*
┃ ⤷ *.قائمة أو .مساعدة* – عرض الأوامر
┃ ⤷ *.تست* – اختبار سريع للبوت
┃ ⤷ *.نطق <نص>* – تحويل نص إلى صوت
┃ ⤷ *.اعترف* – لعبة الاعترافات
┃ ⤷ *.تخيل <وصف>* – توليد صورة بالذكاء
┃ ⤷ *.مين_الوسيم* – من هو الوسيم؟
┃ ⤷ *.تحدي* – بدء تحدي مع البوت
╰─────────🎯─────────╯

╭─────────🛡️─────────╮
┃ 👮‍♂️ *أوامر الإدارة:*
┃ ⤷ *.طرد @* – طرد عضو
┃ ⤷ *.حظر @* – حظر عضو
┃ ⤷ *.ترقية @ / .خفض @* – تعديل الصلاحيات
┃ ⤷ *.منع_رابط / .منع_منشن*
┃ ⤷ *.ترحيب on/off | .توديع on/off*
┃ ⤷ *.كتم <دقائق> | .الغاء_كتم*
┃ ⤷ *.بلوك | .الغاء_بلوك*
┃ ⤷ *.فخ* – إعداد فخ للعضو
┃ ⤷ *.اعضاء* – عرض عدد الأعضاء
┃ ⤷ *.مخفي <رسالة>* – رسالة مخفية
┃ ⤷ *.تغيير_رابط*
╰─────────🛡️─────────╯

╭─────────💞─────────╮
┃ 💍 *أوامر الزواج والعلاقات:*
┃ ⤷ *.تزوج @* – طلب زواج
┃ ⤷ *.زوجتي* – عرض الزوجة
┃ ⤷ *.طلاق* – إنهاء العلاقة
┃ ⤷ *.احضن @* – حضن رقمي
╰─────────💞─────────╯

╭─────────📥─────────╮
┃ 🎶 *أوامر التحميل:*
┃ ⤷ *.تشغيل <اسم>* – تشغيل أغنية
┃ ⤷ *.يوتيوب / .فيديو / .تيك_توك*
┃ ⤷ *.انستغرام / .فيسبوك*
╰─────────📥─────────╯
┃ ⤷ *.ستيكر (رد على صورة)*
┃ ⤷ *.لصورة (رد على ملصق)*
┃ ⤷ *.حذف_خلفية | .تغشيم | .مزج*
╰─────────🎨─────────╯`;

try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        
        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {

newsletterName: '∆§Elgrande mounir§∆',
                        serverMessageId: -1
                    }
                }
            },{ quoted: message });
        } else {
            console.error('Bot image not found at:', imagePath);
            await sock.sendMessage(chatId, { 
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {

                        newsletterName: '∆§Elgrande mounir§∆',
                        serverMessageId: -1
                    } 
                }
            });
        }
    } catch (error) {
        console.error('Error in help command:', error);
        await sock.sendMessage(chatId, { text: helpMessage });
    }
}

module.exports = helpCommand;