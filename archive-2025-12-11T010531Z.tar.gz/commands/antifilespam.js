
    
const spamMap = new Map();

function getMediaId(msg) {

  const type = Object.keys(msg.message)[0];

  const media = msg.message[type];

  if (media.fileSha256) return media.fileSha256.toString('base64');

  if (media.fileHash) return media.fileHash.toString('base64');

  return JSON.stringify(media);

}

async function handleAntiFileSpam(sock, msg) {

  try {

    const jid = msg.key.remoteJid;

    const sender = msg.key.participant || msg.key.remoteJid;

    if (!jid.endsWith('@g.us') || !sender || !msg.message) return;

    const type = Object.keys(msg.message)[0];

    if (type === 'conversation' || type === 'extendedTextMessage') return;

    const content = getMediaId(msg);

    const key = `jid:{sender}`;

if (!spamMap.has(key)) spamMap.set(key, []);

    const history = spamMap.get(key);

    history.push({ id: msg.key.id, content });

    if (history.length > 4) history.shift();

    const repeated = history.filter(h => h.content === content);

    if (repeated.length >= 4) {

      // 🟥 حذف الرسائل المتكررة

      for (const item of repeated) {

        await sock.sendMessage(jid, {

          delete: {

            remoteJid: jid,

            fromMe: false,

            id: item.id,

            participant: sender,

          },

        });

      }

      // 🟥 طرد العضو

      await sock.groupParticipantsUpdate(jid, [sender], 'remove');

      await sock.sendMessage(jid, {

        text: `       彡『*𝔈𝔩𝔤𝔯𝔞𝔫𝔡𝔢_.𝔪𝔬𝔲𝔫𝔦𝔯*』彡


_*🚫 تم طرد العضو بسبب تكرار نفس الملف 5 مرات وتم حذف رسائله.*`,

      });

      spamMap.delete(key);

    }

  } catch (err) {

    console.error('❌ خطأ في handleAntiFileSpam:', err);

  }

}

module.exports = { handleAntiFileSpam };