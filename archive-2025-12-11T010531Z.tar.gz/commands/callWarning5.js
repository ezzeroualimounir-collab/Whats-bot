const fs = require('fs');

const warningsFile = './data/callWarnings.json';

function loadWarnings() {

  if (fs.existsSync(warningsFile)) {

    return JSON.parse(fs.readFileSync(warningsFile));

  }

  return {};

}

function saveWarnings(data) {

  fs.writeFileSync(warningsFile, JSON.stringify(data, null, 2));

}

async function handleCall(sock, callEvent) {

  const { from, id } = callEvent;

  // فقط المكالمات داخل الجروب

  if (!id.endsWith('@g.us')) return;

  const userJid = from;

  const groupId = id;

  const warnings = loadWarnings();

  warnings[userJid] = (warnings[userJid] || 0) + 1;

  if (warnings[userJid] >= 3) {

    await sock.sendMessage(groupId, {

      text: `🚫 تم طرد @${userJid.split('@')[0]} بسبب تكرار المكالمات! (3/3)`,

      mentions: [userJid],

});

    await sock.groupParticipantsUpdate(groupId, [userJid], 'remove').catch(() => {});
    delete warnings[userJid];

  } else {

    await sock.sendMessage(groupId, 
{
      text: `⚠️ إنذار${warnings[userJid]}: @${userJid.split('@')[0]} لا تتصل بالمجموعة مجددًا!`,

      mentions: [userJid],

    });

  }

  saveWarnings(warnings);

}

module.exports = { handleCall };