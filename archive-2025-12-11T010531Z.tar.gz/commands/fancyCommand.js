const fancyText = require('../data/fancyText');

module.exports = async function fancyCommand(sock, message) {

  const chatId = message.key.remoteJid;

  const text = message.message?.conversation || message.message?.extendedTextMessage?.text;

  const inputParts = text?.split(' ').slice(1);

  

  if (!inputParts || inputParts.length === 0) {

await sock.sendMessage(chatId, { text: '✏️ اكتب نص وزيد رقم النمط (1-4) اختياري\nمثال:\n.zakhrafa Hello 2' }, { quoted: message });

    return;

  }

  const styleNum = inputParts[inputParts.length - 1];
const styles = ['style1', 'style2', 'style3', 'style4'];

const inputText = styles.includes('style' + styleNum) ? inputParts.slice(0, -1).join(' ') : inputParts.join(' ');

const results = styles.map(style => fancyText(inputText, style));

const messageText = `*_زخرفة كلمة ${inputText}_*` + results.map((res, i) => `✨ شكل${i+1}:\n${res}`).join('\n\n');

await sock.sendMessage(chatId, {
  text: messageText
}, { quoted: message });
    };