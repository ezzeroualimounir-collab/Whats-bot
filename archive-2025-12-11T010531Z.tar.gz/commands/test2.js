const path = require('path');

async function handleTestCommand(sock, msg) {

  const chatId = msg.key.remoteJid;
try {

        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');

        

        if (fs.existsSync(imagePath)) {

            const imageBuffer = fs.readFileSync(imagePath);

            

            await sock.sendMessage(chatId, {

                image: imageBuffer,

                caption: '*👑خدام أعشيري شنو بغيتي📝💡*',
    },{quoted : msg });     
  

  // إرسال مقطع صوتي

  const audioPath = path.join(__dirname, 'media', 'test.opus'); // تأكد من وجود الملف

  await sock.sendMessage(chatId, {

    audio: { url: audioPath },

    mimetype: 'audio/mp4', // أو audio/mpeg حسب نوع الملف



  }, { quoted: msg });

}

module.exports = handleTestCommand;