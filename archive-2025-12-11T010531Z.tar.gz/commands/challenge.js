const challenges = [

  '📸 أرسل صورة من ألبومك خلال 10 ثواني!',

  '🎤 غنّي أغنية بصوتك وأرسلها الآن!',

  '😂 اكتب جملة من دون استخدام حرف "ا".',

  '📱 أرسل آخر رسالة وصلتك في الخاص (بدون كذب 😜)',

  '🕺 قم بتقليد شخصية مشهورة وأرسل مقطع صوتي.',

  '📢 قل بصوتك: "أنا أحب هذا الجروب أكثر من حياتي!"',

  '✍️ اكتب نكتة جديدة من تأليفك.',

  '🎮 اذكر اسم لعبة مفضلة لديك وخلي غيرك يجربها.',

  '💬 لا تكتب أي رسالة لمدة 5 دقائق. اللي يخالف يعاقب 😂',

  '🎭 أرسل ملصق يعبر عن حالتك النفسية الآن.',

];

async function handleChallenge(sock, chatId, msg) {

  const random = challenges[Math.floor(Math.random() * challenges.length)];

  await sock.sendMessage(chatId, {

    text: `🧩 تحدي عشوائي:\n\n${random}`,

  }, { quoted: msg });

}

module.exports = { handleChallenge };